# T02 - (The TwoTwos)

![Team Photo](https://github.com/csucs314s19/t02/blob/master/team/Images/puppy1.jpg)

### Here is where we will update our stuff, but for now cute puppies!

|     name             | eID          | GitHub Username | Email                               |
|----------------------|--------------|-----------------|-------------------------------------|
|Joel Topps            |jtopps        |JTopps           |jtopps@rams.colostate.edu            |
|Maritza Gonzalez      |mgonzo10      |mgonzo10         |mgonzo10@rams.colostate.edu          |
|Wenhao Li             |jaylizz       |jaylizzhn        |jaylizz@rams.colostate.edu           |
|Wenrui Ma             |wenrui        |wnr210           |wenrui@rams.colostate.edu           |
