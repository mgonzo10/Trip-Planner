import React, {Component} from 'react';
import {Container, Row, Col} from 'reactstrap';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import 'leaflet/dist/leaflet.css';
import { Map, Marker, Popup, TileLayer} from 'react-leaflet';
import Pane from './Pane'
import {
    LayersControl,
}from 'react-leaflet'
import L from 'leaflet'

const {BaseLayer } = LayersControl;
/*
 * Renders the home page.
 */
export default class Home extends Component {
    constructor(props){
        super(props);

        this.getLocation = this.getLocation.bind(this);
        this.currentLocation = this.currentLocation.bind(this);
        this.state = {pos: null};
    }

  render() {
    return (
      <Container>
        <Row>
          <Col xs={12} sm={12} md={7} lg={8} xl={9}>
            {this.renderMap()}
          </Col>
          <Col xs={12} sm={12} md={5} lg={4} xl={3}>
            {this.renderIntro()}
          </Col>
        </Row>
      </Container>
    );
  }

  renderMap() {
    return (
      <Pane header={'Where Am I?'}
            bodyJSX={this.renderLeafletMap()}/>
    );
  }

  renderLeafletMap() {
    // initial map placement can use either of these approaches:
    // 1: bounds={this.coloradoGeographicBoundaries()}
    // 2: center={this.csuOvalGeographicCoordinates()} zoom={10}
    // Code inspired from PaulLeCam https://github.com/PaulLeCam/react-leaflet/blob/master/example/components/layers-control.js?fbclid=IwAR128m2BG7miT94Sf5PZb0LecaoiZb_ROyan8INIRuB_qFRfb7_4CFCYse4
    //
      this.currentLocation();
      if(this.state.pos == null){this.setState({pos: this.csuOvalGeographicCoordinates()});}
    return (

      <Map center={this.state.pos} zoom={16}
           style={{height: 500, maxwidth: 700}}>
        <LayersControl position = "topright">
            <BaseLayer checked name= "OpenStreetMap.Mapnik">
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                   attribution="&copy; <a href=&quot;http://osm.org/copyright&quot;>OpenStreetMap</a> contributors"
                />
            </BaseLayer>
            <BaseLayer name = "OpenStreetMap.BlackAndWhite">
                <TileLayer
                    attribution="&quot;&amp;copy <a href=&quot;http://osm.org/copyright&quot>OpenStreetMap</a> contributors"
                    url="https://tiles.wmflabs.org/bw-mapnik/{z}/{x}/{y}.png"
                />
            </BaseLayer>
            <BaseLayer name = "Thunderforest.TransportDark">
                <TileLayer
                    attribution = "&copy; <a href=&quot;http://www.thunderforest.com/&quot;>Thunderforest</a>, &copy; <a href=&quot;https://www.openstreetmap.org/copyright&quot;>OpenStreetMap</a> contributors"
                    url= "https://{s}.tile.thunderforest.com/transport-dark/{z}/{x}/{y}.png"
                />
            </BaseLayer>
            <BaseLayer name = "Stamen.Watercolor">
                <TileLayer
                    attribution = "Map tiles by <a href=&quot;http://stamen.com&quot;>Stamen Design</a>, <a href=&quot;http://creativecommons.org/licenses/by/3.0&quot;>CC BY 3.0</a> &mdash; Map data &copy; <a href=&quot;https://www.openstreetmap.org/copyright&quot;>OpenStreetMap</a> contributors"
                    url = "https://stamen-tiles-{s}.a.ssl.fastly.net/watercolor/{z}/{x}/{y}.png"
                />
            </BaseLayer>
            <BaseLayer name = "OpenTopoMap">
                <TileLayer
                    attribution= "&copy; <a href=&quot;https://www.openstreetmap.org/copyright&quot;>OpenStreetMap</a> contributors, <a href=&quot;http://viewfinderpanoramas.org&quot;>SRTM</a> | Map style: &copy; <a href=&quot;https://opentopomap.org&quot;>OpenTopoMap</a> (<a href=&quot;https://creativecommons.org/licenses/by-sa/3.0/&quot;>CC-BY-SA</a>)"
                    url= "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png"
                />
            </BaseLayer>
            <BaseLayer name = "Thunderforest.OpenCycleMap">
                <TileLayer
                    attribution= "&copy; <a href=&quot;http://www.thunderforest.com/&quot;>Thunderforest</a>, &copy; <a href=&quot;https://www.openstreetmap.org/copyright&quot;>OpenStreetMap</a> contributors"
                    url= "https://{s}.tile.thunderforest.com/cycle/{z}/{x}/{y}.png"
                />
            </BaseLayer>
            <Marker position={this.state.pos}
                icon={this.markerIcon()}>
                <Popup className="font-weight-extrabold">Colorado State University</Popup>
            </Marker>
        </LayersControl>
      </Map>
    )
  }

  renderIntro() {
    return(
      <Pane header={'Bon Voyage!'}
            bodyJSX={'Let us help you plan your next trip.'}/>
    );
  }

  coloradoGeographicBoundaries() {
    // northwest and southeast corners of the state of Colorado
    return L.latLngBounds(L.latLng(41, -109), L.latLng(37, -102));
  }

  csuOvalGeographicCoordinates() {
      // console.log("asdfghjkl");
      //console.log(L);
      // console.log("asdfghjkl");
    return L.latLng(40.576179, -105.080773);
  }

  getLocation(location){

      let latlng = new L.LatLng(
          location.coords.latitude,
          location.coords.longitude
          );
      this.setState({pos: latlng});
  }
  currentLocation() {
    //console.log(123);
    navigator.geolocation.getCurrentPosition(this.getLocation);
    //console.log(latlng);

  }


  markerIcon() {
    // react-leaflet does not currently handle default marker icons correctly,
    // so we must create our own
    return L.icon({
      iconUrl: icon,
      shadowUrl: iconShadow,
      iconAnchor: [12,40]  // for proper placement
    })
  }
}
