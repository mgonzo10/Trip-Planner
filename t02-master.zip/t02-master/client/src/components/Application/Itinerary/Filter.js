import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import { Label,InputGroup, InputGroupAddon, Input,ButtonToolbar } from 'reactstrap'
import Pane from '../Pane';
import { Table } from 'reactstrap';
import { FormGroup, FormText } from 'reactstrap';
import { Button, ButtonGroup } from 'reactstrap';
class Filter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            narrow:[
                {   "name" : "",
                    "values" : [],
                }],

            cSelected: [],


        };
        this.makeOneFilter = this.makeOneFilter.bind(this);
        this.makeAllFilter = this.makeAllFilter.bind(this);
        this.checkAllFilter = this.checkAllFilter.bind(this);
        this.checkOneFilter = this.checkOneFilter.bind(this);
        this.onCheckboxBtnClick = this.onCheckboxBtnClick.bind(this);
        this.saveFilters = this.saveFilters.bind(this);

    }


    onCheckboxBtnClick(selected) {
        const index = this.state.cSelected.indexOf(selected);
        if (index < 0) {
            this.state.cSelected.push(selected);
        } else {
            this.state.cSelected.splice(index, 1);
        }
        this.setState({ cSelected: [...this.state.cSelected] });
    }

    makeOneFilter(filter){
        //only handling the current filter situation: only one-- type
        let but = [];
        for(let i = 0; i < filter.values.length; i++){
            // console.log("con.values: " + con.values[i]);mvn pa
            but.push(<Button name={filter.name} color={"outline-info"} onClick={()=>this.onCheckboxBtnClick(filter.values[i])} active={this.state.cSelected.includes(filter.values[i])} >{filter.values[i]}</Button>)
        }
        return but;
    }

    makeAllFilter()
    {
        let allButton = [];
        let filters = this.props.serverConfig.filters;
        //console.log("here in making all filters")
        //console.log(filters)

        for(let i=0;i<filters.length;i++)
            {
                //console.log("here in making all nxt filters")
                //console.log(filters[i])
                let buttons = this.makeOneFilter(filters[i]);
                allButton.push(<ButtonGroup id={filters[i].name} size="sm">
                    {buttons}
                </ButtonGroup>);
            }

        return (
            <ButtonToolbar>
                {allButton}
            </ButtonToolbar>)
    }
    /*
       narrow:[
                {   "name" : "",
                    "values" : [],
                }],
     */
    checkAllFilter()
    {
        let filters = this.props.serverConfig.filters;
        let tempFilters=[];

        for(let i=0;i<filters.length;i++)
        {
            console.log("here in check all filters")

            let tempFilter={};
            let values =[];

           values =  this.checkOneFilter(filters[i]);
           if(values.length!=0)
           {

               tempFilter.name = filters[i].name;
               tempFilter.values = values;
               console.log(tempFilter)

               tempFilters.push(tempFilter)


           }

        }
        return tempFilters;

    }
    checkOneFilter(filter)
    {
        let values = [];
        for(let i=0;i<filter.values.length;i++)
        {
          if(this.state.cSelected.includes(filter.values[i]))
          {
                values.push( filter.values[i]);
          }
        }
        return values;

    }

    saveFilters() {
     let allFilters = this.checkAllFilter();
     this.setState({narrow: allFilters});
     this.props.updateFind("narrow",allFilters);

    }

    render() {
        // need to update the options when a button is pressed
        let buttons = this.makeAllFilter();
       return(
           <Pane
               header={"Select your filters"}
               bodyJSX={
                   <div>
                       {buttons}
                       <Button color="outline-info" className="float-right" onClick={this.saveFilters} type="button">Save Filter</Button>
                   </div>
               }
           />
       )

    }
}

export default Filter;