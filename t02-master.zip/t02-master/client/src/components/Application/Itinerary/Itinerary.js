import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import { Modal, ModalHeader, ModalBody, ModalFooter,Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import { Label,InputGroup, InputGroupAddon, Input,ButtonToolbar } from 'reactstrap'
import { sendServerRequestWithBody } from '../../../api/restfulAPI'
import Pane from '../Pane';
import { Table } from 'reactstrap';
import { Form, FormGroup, FormText } from 'reactstrap';
import {getOriginalServerPort} from "../../../api/restfulAPI";
import { Button, ButtonGroup } from 'reactstrap';
import * as schema from '../../../../../server/src/main/resources/TIPItinerarySchema.json';
import 'leaflet/dist/leaflet.css';
import {Map, Marker, Popup, TileLayer, Polyline, LayersControl} from 'react-leaflet';
import Find from "./Find";
import MapMarker from "./MapMarker";
import Download from "./Download";
import CustomePlace from "./CustomePlace";
import TableItinerary from "./TableItinerary";

export default class Itinerary extends Component {
    constructor(props) {
        super(props);
        this.sendResponse = this.sendResponse.bind(this);
        this.getFile = this.getFile.bind(this);
        this.setOptimization=this.setOptimization.bind(this);
        this.updateMarker=this.updateMarker.bind(this);
        this.toggle = this.toggle.bind(this);
        this.ReverseItinerary = this.ReverseItinerary.bind(this);


        this.state = {
            dropdownOpen : false,
            serverConfig: null,
            errorMessage: null,
            options: null,
            places: [],
            distances: [],
            clientSettings: {
                serverPort: getOriginalServerPort()
            },
//  //"placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "altitude"],
            markers:[],
            markerNames:[],
            selected:["name","leg distance","cumulative distance"],
            newPlace:{},
     //      isl:[] lList:[]
            disl:[],
            dism:[]
            };



    }
    toggle(event) {
        this.setState({
            dropdownOpen: !this.state.dropdownOpen
        });
    }



    updateMarker(markersnew, markernamesnew)
        {
        this.setState({markers: markersnew,
        markerNames:markernamesnew});
    }



    getFile(evt){
        let reader = new FileReader();
        reader.onload = function(evt) {
            let fileContents = evt.target.result;
            let contents = JSON.parse(fileContents);

            if(contents.options.optimization===undefined)
            {
                contents.options.optimization="none"
            }
            if(contents.distances == null){
                contents.distances = [];
            }
            this.props.updateResponse(contents);
            this.setState(
                {
                    options:contents.options,
                    distances:contents.distances,
                    places:contents.places
                }
                ,this.sendResponse
            );

        }.bind(this);
        reader.readAsText(evt.target.files[0]);

    }
    sendResponse() {
        console.log("hrere send response in intinereray.js")
        let Coordinates = require('coordinate-parser');
        let temp = this.props.itinerary.places;
        let try1;
        for(let i=0;i<temp.length;i++)
        {
            try1 = new Coordinates(this.props.itinerary.places[i].latitude.toString() + " " + this.props.itinerary.places[i].longitude.toString());
            temp[i].latitude = try1.getLatitude().toString(); // 40.123 ✓
            temp[i].longitude = try1.getLongitude().toString();
        }

        let opt = this.props.itinerary.options.optimization;
        opt= opt? opt.toString():"none"
        let optionTemp={
            'earthRadius' : (this.props.options.units[this.props.options.activeUnit]).toString(),
            'optimization' : opt

        }

        const tipItineraryRequest = {
            'requestType': 'itinerary',
            'requestVersion': 4,
            'options': Object.assign({}, optionTemp),
            'places': temp,
            'distances':this.state.distances
        };

        console.log("tipItineraryRequest!!!!!!!!!");
        console.log(tipItineraryRequest);

        sendServerRequestWithBody('itinerary', tipItineraryRequest, this.props.settings.serverPort).then((response) => {

            console.log(" the respeonse from server of the itinerary!!!!!!!!!");
            let Ajv = require('ajv');
            let ajv = new Ajv(); // options can be passed, e.g. {allErrors: true}
            let validate = ajv.compile(schema);
            console.log(response);

            if (response.statusCode >= 200 && response.statusCode <= 299) {
                this.setState({
                    options: response.body.options,
                    places: response.body.places,
                    distances: response.body.distances,
                    errorMessage: null
                });

                this.props.updateItinerary("options",response.body.options);
                this.props.updateItinerary("distances",response.body.distances);
                this.props.updateItinerary("places",response.body.places);

            }
            else {
                if(response.statusCode === 400)
                {
                    this.setState({
                        errorMessage: this.props.createErrorBanner(
                            response.statusText,
                            response.statusCode,

                            `Please enter a valid JSON file!`
                        )
                    });
                }
                else
                {
                    this.setState({
                        errorMessage: this.props.createErrorBanner(
                            response.statusText,
                            response.statusCode,
                            `Request to ${ this.props.settings.serverPort } failed.`
                        )
                    });
                }



            }
        });
    }

    setOptimization(event){
        let temp = this.props.itinerary.options;
        temp.optimization=event.target.name;
        this.setState({options:temp});
        this.props.updateItinerary("options",temp);
        this.sendResponse();
    }

  renderOpt() {
      return <Dropdown isOpen={this.state.dropdownOpen} name = "dropdownOpen"
                toggle={this.toggle}>
          <DropdownToggle caret color="outline-info">
              Optimization
          </DropdownToggle>
          <DropdownMenu>
              {["none","short","shorter"].map(variant =>
                  (
                      <DropdownItem  name={variant}  onClick={this.setOptimization}>{variant}</DropdownItem>
                  )
              ) }
          </DropdownMenu>
      </Dropdown>
  }

    renderPlan(){
        return(
            <Pane
                header={"Plan, Modify, Save Your Trip Here"}
                bodyJSX={
                    <div>
                        <ButtonToolbar>
                            <ButtonGroup className="mr-2" aria-label="First group">
                                 <Button onClick={this.sendResponse} color="outline-info">Plan</Button>
                            </ButtonGroup>
                            <ButtonGroup className="mr-2" aria-label="First group">
                                 <Button color="outline-info" onClick={this.ReverseItinerary}>Reverse</Button>
                            </ButtonGroup>
                            <ButtonGroup className="mr-2" aria-label="First group">
                                <Download
                                    serverConfig={this.props.serverConfig}
                                    itinerary={this.props.itinerary}
                                />
                            </ButtonGroup>
                            <ButtonGroup className="mr-2" aria-label="First group">
                                {this.renderOpt()}
                            </ButtonGroup>
                            <ButtonGroup className="mr-2" aria-label="First group">
                                <Find
                                    addPlace={this.props.addPlace}
                                    settings={this.state.clientSettings}
                                    find={this.props.find}
                                    serverConfig={this.props.serverConfig}
                                    itinerary={this.props.itinerary}
                                    updateFind={this.props.updateFind}
                                    createErrorBanner={this.props.createErrorBanner}
                                    makeButtons = {this.makeButtons}
                                    onCheckboxBtnClick = {this.onCheckboxBtnClick}
                                    createTable = {this.createTable}
                                />
                            </ButtonGroup>
                            <ButtonGroup className="mr-2" aria-label="First group">

                            <CustomePlace itinerary={this.props.itinerary}
                                          updateItinerary={this.props.updateItinerary}
                            />
                            </ButtonGroup>

                        </ButtonToolbar>
                   </div>
                }
            />
        )
    }

    ReverseItinerary(){
        let temp = this.props.itinerary.places;
        temp.reverse();
        this.props.updateItinerary("places",temp);
        this.sendResponse();

    }



    renderFileUpload(){
        return(
            <Pane
                header={"Upload Your File Here"}
                bodyJSX={<FormGroup>
                    <Label for="exampleFile">File</Label>
                    <Input type="file" name="file" id="exampleFile" class="btn btn-outline-info" color="outline-info" onChange={this.getFile}/>
                    <FormText>
                        Please use a .txt
                    </FormText>
                </FormGroup>}
            />

        );
    }
    render() {
        return (
            <Container>
                { this.state.errorMessage }
                <Row>
                    <Col>
                            {this.renderPlan()}
                    </Col>
                </Row>
                <Row>
                    <Col>
                        {this.renderFileUpload()}

                        <MapMarker itinerary={this.props.itinerary}
                                   markers = {this.state.markers}
                                   disl= {this.state.disl}
                                   dism= {this.state.dism}

                        />
                        <TableItinerary itinerary={this.props.itinerary}
                                        updateItinerary={this.props.updateItinerary}
                                        serverConfig={this.props.serverConfig}
                                        markers = {this.state.markers}
                                        markerNames = {this.state.markerNames}
                                        updateMarker={this.updateMarker}
                                        makeButtons = {this.makeButtons}
                                        onCheckboxBtnClick = {this.onCheckboxBtnClick}
                                        createTable = {this.createTable}/>
                    </Col>
                </Row>
            </Container>

        );
    }

}



