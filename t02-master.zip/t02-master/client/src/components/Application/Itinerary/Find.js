import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import { Button } from 'reactstrap'
import { Modal, ModalHeader, ModalBody, ModalFooter,Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import { Label,InputGroup, InputGroupAddon, Input } from 'reactstrap'
import { sendServerRequestWithBody } from '../../../api/restfulAPI'
import Pane from '../Pane';
import { Table } from 'reactstrap';
import { FormGroup, FormText } from 'reactstrap';
import {getOriginalServerPort} from "../../../api/restfulAPI";
import Filter from "./Filter.js";
import TableColSelector from "./TableColSelector.js";

import * as schema from '../../../../../server/src/main/resources/TIPFindSchema.json';
import { Map, Marker, TileLayer, Polyline} from 'react-leaflet';


//use stringify


/**{
 "requestType"    : "find",
 "requestVersion" : 3,
 "match"          : "",
 "limit"          : 0,
 "found"          : 0,
 "places"         : []
 }*/

export default class Find extends Component {
    constructor(props) {
        super(props);
        this.sendResponse = this.sendResponse.bind(this);
        this.getTableInfo = this.getTableInfo.bind(this);
        this.newQuery=this.newQuery.bind(this);
        this.updateFindMatch=this.updateFindMatch.bind(this);
        this.addButton=this.addButton.bind(this);
        this.addEntry=this.addEntry.bind(this);
        this.sanitizeInput=this.sanitizeInput.bind(this);
        this.tdCreateHelper=this.tdCreateHelper.bind(this);
        this.itineraryUpdateSelected = this.itineraryUpdateSelected.bind(this);
        this.colSelectors = this.colSelectors.bind(this);
        this.toggle = this.toggle.bind(this);



        this.state = {
            serverConfig: null,
            errorMessage: null,
            match          : "",
            limit          : 0,
            found          : 0,
            places         : [],
            narrow: [],
            clientSettings: {
                serverPort: getOriginalServerPort()
            },
//  //"placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "altitude"],
           selected:["id","municipality"],
            modalOpen: false


        };

    }
    toggle(event) {
        let name = event.target.name;
        this.setState({
            modalOpen: !this.state.modalOpen
        });
    }

    render()
    {
        return <span>
                <Button onClick={this.toggle}   color="outline-info">
                    Search & Add your place!
                </Button>
                <Modal isOpen={this.state.modalOpen} toggle={this.toggle} name = "modalOpen"
                       size="lg"
                       aria-labelledby="contained-modal-title-vcenter"
                       centered
                >
                    <ModalBody>
                         <p> Type your place in the box, then click search.</p>
                          <p>Select the type of place you want as the filter, then click save.</p>
                        {this.renderFind()}
                    </ModalBody>

                </Modal>
            </span>
    }

    renderFind() {
        return (
            <div>
                { this.state.errorMessage }
                <Row>
                    <Col>
                        <Filter
                            addPlace={this.props.addPlace}
                            settings={this.state.clientSettings}
                            find={this.props.find}
                            serverConfig={this.props.serverConfig}
                            itinerary={this.props.itinerary}
                            updateFind={this.props.updateFind}
                            createErrorBanner={this.props.createErrorBanner}
                        />
                    </Col>
                </Row>
                <Row>
                    <Col>
                    {this.renderDBinput()}
                    </Col>
                </Row>
                <Row>
                    <Col>
                        {this.colSelectors()}
                    </Col>
                </Row>


            </div>

        );
    }


    colSelectors()
    {
        let selectors = <TableColSelector
                        getTableInfo = {this.getTableInfo}
                        serverConfig={this.props.serverConfig}
                        initialselected={[]}
                        itineraryUpdateSelected ={this.itineraryUpdateSelected}
                        />

        return  <Pane header={'Select what to display for the search results!'}
                      bodyJSX={selectors}
        />
    }

    itineraryUpdateSelected(newSelcted)
    {
        this.setState(
            {
                selected:newSelcted
            }
        )
    }

/*
//  //"placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "altitude"],

public class Place{
  public String id;
  public String name;
  public String latitude;
  public String longitude;
  public String municipality;
  public String altitude;
 */
    tdCreateHelper(name,j)
    {
        console.log("here inside tdcreateHelper")
        console.log(name)

       let t=
            <div>
                <div>{name}</div>
                <div className="input-group-prepend">
                    <div onClick={this.addButton.bind(this)}>
                        <Button size = "sm" id={"oOutline"} name={j} type="button" color="outline-info">Add</Button>
                    </div>
                </div>
            </div>
        return t;

    }

    getTableInfo(){
        let table = [];
        let places = this.state.places;
        let selected = this.state.selected;
        if(this.state.places!=null)
        {
            for(let j=0;j<places.length;j++)
            {
                let oneline =[];

                oneline.push( <td>{this.tdCreateHelper(places[j].name,j)}</td>);
                console.log("here is")
                console.log(this.tdCreateHelper(places[j].name,j))

                for(let i=0;i<selected.length;i++)
                {
                    if(places[j].hasOwnProperty(selected[i]) )
                    {
                        let attribute = selected[i];
                        oneline.push(<td>{places[j][attribute]}</td>)
                    }
                    else {
                        oneline.push(<td>&nbsp;</td>)
                    }
                }

                table.push(<tr>{oneline}</tr>)
            }
            return table;
        }
    }



    addButton(event){
        //for(let i =0; i<this.props.query.places.length;){
        this.addEntry(this.props.find.places[event.target.name]);
        this.props.find.places.splice(event.target.name, 1);
        //}
    }

    addEntry(arg){
        this.props.addPlace(arg);
    }



    /**{
 "requestType"    : "find",
 "requestVersion" : 3,
 "match"          : "",
 "limit"          : 0,
 "found"          : 0,
 "places"         : []
 }
     document.getElementById("search").value.toString()*/
    sendResponse() {

        let matchfiled = document.getElementById("search").value.toString();
        //alert("check here:")
        const tipFindRequest = {
            'requestType': 'find',
            'requestVersion': 4,
            'match': this.sanitizeInput(matchfiled),
            'narrow': this.props.find.narrow,
            'limit': this.props.find.limit,
            'found': this.props.find.found,
            'places': this.props.find.places,

        };
        console.log("inside sendresponse by search");

        console.log(tipFindRequest);

        sendServerRequestWithBody('find', tipFindRequest, this.props.settings.serverPort).then((response) => {


            console.log("inside sendServerRequestWithBody by search");

            console.log(response);

           let Ajv = require('ajv');
            let ajv = new Ajv(); // options can be passed, e.g. {allErrors: true}
            let validate = ajv.compile(schema);
            let valid = validate(response.body);
            //console.log(valid);
            if(valid == false) {
                console.log("here, the server response is not passing the client schema")
                response.statusCode=400;
                this.setState({
                    errorMessage: this.props.createErrorBanner(
                        response.statusText,
                        response.statusCode,
                        `Client Side Schema Failed!`
                    ),
                });
            }
            else if (response.statusCode >= 200 && response.statusCode <= 299) {


                this.setState({

                    limit: response.body.limit,
                    found: response.body.found,
                    places: response.body.places,
                    narrow: response.body.narrow,

                    errorMessage: null
                });
                this.props.updateFind("limit",response.body.limit);
                this.props.updateFind("found",response.body.found);
                this.props.updateFind("places",response.body.places);

            }
            else if(response.statusCode==400){
                    this.setState({
                        errorMessage: this.props.createErrorBanner(
                            response.statusText,
                            response.statusCode,
                            `Enter Valid Search Parameter!`
                        )
                    });
                }

                else {
                    this.setState({
                        errorMessage: this.props.createErrorBanner(
                            response.statusText,
                            response.statusCode,
                            `Request to ${ this.props.settings.serverPort } failed.`
                        )
                    });
                }


            //console.log(response)
        });
    }




/*
     find: {
       "requestType"    : "find",
       "requestVersion" : 3,
       "match"          : "",
       "limit"          : 0,
       "found"          : 0,
       "places"         : []
       },
 */
    newQuery(arg) {
        //this.props.updateOptions(arg);

        arg = this.sanitizeInput(arg)
        console.log("updating the match field inside newquery: ", arg);
        var testQuery = Object.assign({}, this.props.find);
        testQuery.match = arg;
        console.log("testQuery: ", testQuery);
        this.setState({match: arg});
        this.props.updateFind("match",arg);

        this.sendResponse();
    }

    sanitizeInput(arg)
    {
        console.log("here in sanitize")
        arg= arg.replace(/\s\s+/g, ' ');
        console.log(arg)
        console.log(arg.replace(/\W+/g, "_"))
       return arg.replace(/\W+/g, "_")


    }


    updateFindMatch() {

        this.newQuery(document.getElementById("search").value);
    }





    renderDBinput(){
        return(

            <Pane
                header={"Type the place you want to search for"}
                bodyJSX={
                    <InputGroup id="searchEntry">
                        <InputGroupAddon addonType="append"><Button
                                                                    addonType="append"
                                                                    color={"info"}
                                                                    onClick={this.updateFindMatch}
                                                                    type="button">Search
                        </Button></InputGroupAddon>
                        <Input id="search" placeholder="Search for..." type="text" />
                    </InputGroup>
                }
            />
        )
    }


}



