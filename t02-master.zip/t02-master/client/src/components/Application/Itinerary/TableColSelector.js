import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import { Button } from 'reactstrap'
import { Label,InputGroup, InputGroupAddon, Input } from 'reactstrap'
import { sendServerRequestWithBody } from '../../../api/restfulAPI'
import Pane from '../Pane';
import { Table } from 'reactstrap';
import { FormGroup, FormText } from 'reactstrap';
import {getOriginalServerPort} from "../../../api/restfulAPI";
import Filter from "./Filter.js";
import * as schema from '../../../../../server/src/main/resources/TIPFindSchema.json';
import { Map, Marker, TileLayer, Polyline} from 'react-leaflet';
export default class TableColSelector extends Component {


    constructor(props) {
        super(props);


        this.state = {
            serverConfig: null,
            errorMessage: null,
            match: "",
            limit: 0,
            found: 0,
            places: [],
            narrow: [],
            clientSettings: {
                serverPort: getOriginalServerPort()
            },
//  //"placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "altitude"],
            selected: ["leg distance", "cumulative distance"]
        };

        this.makeButtons = this.makeButtons.bind(this);
        this.onCheckboxBtnClick = this.onCheckboxBtnClick.bind(this);
    }


        makeButtons(con2)
        {

            let con1 = this.props.serverConfig.placeAttributes;
            let temp = con1.indexOf("name");
            // let con2 = ["leg distance", "cumulative distance"];
            let con = con1.concat(con2);
            con.splice(temp, 1)
            let but = [];
            for (let i = 0; i < con.length; i++) {
                // console.log("con.values: " + con.values[i]);
                but.push(
                    <label>
                        <input type="checkbox"
                               color={"info"}
                               onChange={() => this.onCheckboxBtnClick(con[i])}
                               checked={this.state.selected.includes(con[i])}
                               name={con[i]}
                        />{con[i] + "  "}
                        <br/>
                    </label>
                )
            }
            return but;

        }

        onCheckboxBtnClick(clicked)
        {
            const index = this.state.selected.indexOf(clicked);
            let temp = this.state.selected;
            if (index < 0) {
                temp.push(clicked);
            } else {
                temp.splice(index, 1);
            }
            this.setState({
                selected: temp
            });
            this.props.itineraryUpdateSelected(temp);
        }

        render()
        {
            let dests = [];
            dests = this.state.selected.map((attribute) => <th>{attribute}</th>);

            return (
                <Container>
                    {this.makeButtons(this.props.initialselected)}
                    <Table responsive>
                        <thead>
                        <tr>
                            <th>{"name"}</th>
                            {dests}
                        </tr>
                        </thead>
                        <tbody>
                        {this.props.getTableInfo()}
                        </tbody>
                    </Table>
                </Container>
            );
        }




}
