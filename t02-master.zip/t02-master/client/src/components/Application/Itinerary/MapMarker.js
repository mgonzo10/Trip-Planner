import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import { Label,InputGroup, InputGroupAddon, Input } from 'reactstrap'
import { Table } from 'reactstrap';
import { Form, FormGroup, FormText } from 'reactstrap';
import { Button, ButtonGroup } from 'reactstrap';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import 'leaflet/dist/leaflet.css';
import {Map, Marker, Popup, TileLayer, Polyline, LayersControl} from 'react-leaflet';
import L from 'leaflet';

const {BaseLayer } = LayersControl;


export default class MapMarker extends Component {
    constructor(props) {
        super(props);
        //this.getPostition = this.getPostition.bind(this);
        this.renderMap = this.renderMap.bind(this);
        this.renderMarker = this.renderMarker.bind(this);
        this.markerIcon = this.markerIcon.bind(this);



        this.state = {

            markers: [],
            markerNames: [],

        };

    }


    render() {
        return (
            <Container>
                <Row>
                    <Col>
                        {this.renderMap()}
                    </Col>
                </Row>
            </Container>

        );
    }


    renderMap(){
        let stuff;
        let tempmarker;
        if((this.props.disl.length!=0) && (this.props.dism.length!=0))
        {
            console.log("!=======0")

            stuff = this.props.disl;
             tempmarker = this.props.dism
            console.log(this.props.disl)
            console.log(this.props.dism)

        }
        else if((this.props.itinerary.length!=0))
        {            console.log("==========0")

            stuff =this.getPostition();
            tempmarker=this.props.markers;
        }
        else {

            stuff =[];
            tempmarker=[]
        }

        return(
            <Map center={L.latLng(40.576179, -105.080773)} zoom={8}
                 style={{height: 500, maxwidth: 700}}>

                <LayersControl position = "topright">
                    <BaseLayer checked name= "OpenStreetMap.Mapnik">
                        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                   attribution="&copy; <a href=&quot;http://osm.org/copyright&quot;>OpenStreetMap</a> contributors"
                        />
                    </BaseLayer>
                    <BaseLayer name = "OpenStreetMap.BlackAndWhite">
                        <TileLayer
                            attribution="&quot;&amp;copy <a href=&quot;http://osm.org/copyright&quot>OpenStreetMap</a> contributors"
                            url="https://tiles.wmflabs.org/bw-mapnik/{z}/{x}/{y}.png"
                        />
                    </BaseLayer>
                    <BaseLayer name = "Thunderforest.TransportDark">
                        <TileLayer
                            attribution = "&copy; <a href=&quot;http://www.thunderforest.com/&quot;>Thunderforest</a>, &copy; <a href=&quot;https://www.openstreetmap.org/copyright&quot;>OpenStreetMap</a> contributors"
                            url= "https://{s}.tile.thunderforest.com/transport-dark/{z}/{x}/{y}.png"
                        />
                    </BaseLayer>
                    <BaseLayer name = "Stamen.Watercolor">
                        <TileLayer
                            attribution = "Map tiles by <a href=&quot;http://stamen.com&quot;>Stamen Design</a>, <a href=&quot;http://creativecommons.org/licenses/by/3.0&quot;>CC BY 3.0</a> &mdash; Map data &copy; <a href=&quot;https://www.openstreetmap.org/copyright&quot;>OpenStreetMap</a> contributors"
                            url = "https://stamen-tiles-{s}.a.ssl.fastly.net/watercolor/{z}/{x}/{y}.png"
                        />
                    </BaseLayer>
                    <BaseLayer name = "OpenTopoMap">
                        <TileLayer
                            attribution= "&copy; <a href=&quot;https://www.openstreetmap.org/copyright&quot;>OpenStreetMap</a> contributors, <a href=&quot;http://viewfinderpanoramas.org&quot;>SRTM</a> | Map style: &copy; <a href=&quot;https://opentopomap.org&quot;>OpenTopoMap</a> (<a href=&quot;https://creativecommons.org/licenses/by-sa/3.0/&quot;>CC-BY-SA</a>)"
                            url= "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png"
                        />
                    </BaseLayer>
                    <BaseLayer name = "Thunderforest.OpenCycleMap">
                        <TileLayer
                            attribution= "&copy; <a href=&quot;http://www.thunderforest.com/&quot;>Thunderforest</a>, &copy; <a href=&quot;https://www.openstreetmap.org/copyright&quot;>OpenStreetMap</a> contributors"
                            url= "https://{s}.tile.thunderforest.com/cycle/{z}/{x}/{y}.png"
                        />
                    </BaseLayer>
                    <Polyline color="black" positions={stuff}/>
                    <div>
                        {tempmarker}
                    </div>


                </LayersControl>
            </Map>
        )
    }


    renderMarker() {
        console.log("here in markerrender")
        let Coordinates = require('coordinate-parser');
        let temp = this.props.itinerary.places;
        let try1;
        let tempMarker = [];
        let lat;
        let long;
        for (let i = 0; i < temp.length; i++) {
            try1 = new Coordinates(this.props.itinerary.places[i].latitude.toString() + " " + this.props.itinerary.places[i].longitude.toString());
            lat = try1.getLatitude()
            long = try1.getLongitude();
            tempMarker[i] = new L.latLng(lat, long);

        }
        return tempMarker.map((location, i) => {
            let tt = new L.latLng(location["latitude"], location["longitude"]);
            console.log("is it getting here or no");
            return <Marker
                position={location}
                icon={this.markerIcon()}/>
        })

    }

    markerIcon() {
        // react-leaflet does not currently handle default marker icons correctly,
        // so we must create our own
        return L.icon({
            iconUrl: icon,
            shadowUrl: iconShadow,
            iconAnchor: [12, 40]  // for proper placement
        })
    }
    getPostition() {
        //console.log("lines")
        let Coordinates = require('coordinate-parser');
        let temp = this.props.itinerary.places;
        let try1;
        let tempMarker = [];
        let lat;
        let long;

        for (let i = 0; i < temp.length; i++) {
            console.log("here in getposition");
            console.log(this.props.itinerary.places[i]);
            //  console.log(this.props.itinerary.places[i].longitude.toString());

            try1 = new Coordinates(this.props.itinerary.places[i].latitude.toString() + " " + this.props.itinerary.places[i].longitude.toString());
            lat = try1.getLatitude()
            long = try1.getLongitude();

            tempMarker[i] = new L.latLng(lat, long);

        }
        if (temp.length > 0) {
            try1 = new Coordinates(this.props.itinerary.places[0].latitude.toString() + " " + this.props.itinerary.places[0].longitude.toString());

            lat = try1.getLatitude()
            long = try1.getLongitude();
            let tt = new L.latLng(lat, long);
            tempMarker.push(tt);
        }
        return tempMarker;
    }


}