import React, { Component } from 'react'
import {Button, Col, Container, Row,Dropdown, DropdownToggle, DropdownMenu, DropdownItem} from "reactstrap";



import Pane from '../Pane';


export default class Download extends Component {
    constructor(props) {
        super(props);

        this.drawLines=this.drawLines.bind(this);
        this.download=this.download.bind(this);
        this.outputKML=this.outputKML.bind(this);
        this.saveCSV=this.saveCSV.bind(this);
        this.creatStringPlace=this.creatStringPlace.bind(this);
        this.toggle = this.toggle.bind(this);
        this.createOne =this.createOne.bind(this)
        this.state={
            dropdownOpen : false
        }

    }

    toggle() {
        this.setState(prevState => ({
            dropdownOpen: !prevState.dropdownOpen
        }));
    }


    //https://ourcodeworld.com/articles/read/189/how-to-create-a-file-and-generate-a-download-with-javascript-in-the-browser-without-a-server
    download(filename, text) {
        //console.log(text);
        let element = document.createElement('a');
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
        element.setAttribute('download', filename);

        element.style.display = 'none';
        document.body.appendChild(element);

        element.click();

        document.body.removeChild(element);
    }

    drawLines(text){
        let temp="";
        for(let i=0;i<text.length-1;i++){
            temp+='    <Placemark>\n' +
                '      <name>Cross-corner line</name>\n' +
                '      <styleUrl>#CrossStyle</styleUrl>\n' +
                '      <LineString>\n' +
                '        <coordinates> '+text[i].longitude+','+text[i].latitude+',0\n' +
                '          '+text[i+1].longitude+','+text[i+1].latitude+',0 </coordinates>\n' +
                '      </LineString>\n' +
                '    </Placemark>\n'
        }

        temp+='    <Placemark>\n' +
            '      <name>Cross-corner line</name>\n' +
            '      <styleUrl>#CrossStyle</styleUrl>\n' +
            '      <LineString>\n' +
            '        <coordinates> '+text[text.length-1].longitude+','+text[text.length-1].latitude+',0\n' +
            '          '+text[0].longitude+','+text[0].latitude+',0 </coordinates>\n' +
            '      </LineString>\n' +
            '    </Placemark>\n'
        return temp;
    }

    makeText(text){
        let temp="";
        temp+=
            '<?xml version="1.0" encoding="UTF-8"?>\n' +
            '<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2" xmlns:kml="http://www.opengis.net/kml/2.2" xmlns:atom="http://www.w3.org/2005/Atom">\n' +
            '    <Document>\n' +
            '        <name>Single Simple Line</name>\n' +
            '        <open>1</open>\n' +
            '        <description>Just a single blue line across Colorado</description>\n' +
            '        <Style id="CrossStyle">\n' +
            '            <LineStyle>\n' +
            '            <color>ffffffb6</color>\n' +
            '                             <width>4</width>\n' +
            '                                       </LineStyle>\n' +
            '        </Style>\n' +
            this.drawLines(text)+
            '    </Document>\n' +
            '</kml>';


        return temp;
    }

    outputKML(filename, text){
        console.log(text);
        let formatedText=this.makeText(text);
        this.download(filename,formatedText);
    }
    creatSingle()
    {
        return ([".TXT",".KML",".CSV"]).map(
            each=>{
                <DropdownItem
                    key={"download_itin"}
                    color= "outline-info"
                    onClick={()=> this.download("itinerary.txt",JSON.stringify(this.props.itinerary))}
                >.TXT
                </DropdownItem>
            }
        )
    }
    createOne(name,file, content)
    {
        return (
            <DropdownItem
                key={"download_itin"}
                color= "outline-info"
                onClick={()=> this.download(file,content)}
            >{name}
            </DropdownItem>
        )
    }

    render(){


                  return <Dropdown isOpen={this.state.dropdownOpen}
                                toggle={this.toggle}
                            >
                       <DropdownToggle caret   color="outline-info">
                           Download
                       </DropdownToggle>
                       <DropdownMenu>
                           {this.createOne(".TXT", "itinerary.txt",JSON.stringify(this.props.itinerary))}
                           {this.createOne(".KML", "itineraryKML.html",this.props.itinerary.places)}
                           {this.createOne(".CSV", "itineraryCSV.csv",this.saveCSV())}
                       </DropdownMenu>
                   </Dropdown>


    }



    creatStringPlace(obj)
    {

        let flag=true;
        let arr = [];
        for (let key in obj) {
            if (obj.hasOwnProperty(key)) {
                let value = obj[key].toString();
                value = value.replace(/"/g, '""')
                arr.push(value);
            }
            else
            {
                arr.push("");
            }
        };
        arr=arr.join(",")
        return arr;
    }

    saveCSV()
    {
        let places = this.props.itinerary.places;
        let header = this.props.serverConfig.placeAttributes;

        console.log("here in saving csv, header,table")

        console.log(places)

        // console.log(table)

        // let csvContent = "data:text/csv;charset=utf-8,";
        let csvContent=[]
        let row = header.join(",");
        csvContent += row + "\n";


        //  result = innerValue.replace(/"/g, '""');

        for(let i=0;i<places.length;i++)
        {
            let place = places[i];
            let placestring = this.creatStringPlace(place)

            csvContent += placestring + "\n";
        }
        return csvContent;
        /*table.forEach((rowArray) => {
            let row = rowArray.replace(/"/g, '""')
             row = rowArray.join(",");
            csvContent += row + "\r";
        });*/



    }




}