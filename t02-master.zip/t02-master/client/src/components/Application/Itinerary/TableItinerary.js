import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import { Label,InputGroup, InputGroupAddon, Input } from 'reactstrap'
import Pane from '../Pane';
import { Table } from 'reactstrap';
import { Form, FormGroup, FormText } from 'reactstrap';
import { Button, ButtonGroup } from 'reactstrap';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import 'leaflet/dist/leaflet.css';
import {Map, Marker, Popup, TileLayer, Polyline, LayersControl} from 'react-leaflet';
import TableColSelector from "./TableColSelector.js";
import L from 'leaflet';


export default class TableItinerary extends Component {
    constructor(props) {
        super(props);
        this.RemoveItinerary = this.RemoveItinerary.bind(this);
        this.SetAsStart = this.SetAsStart.bind(this);
        this.HandleOneMarker = this.HandleOneMarker.bind(this);
        this.getTableInfo = this.getTableInfo.bind(this);
        this.tdCreateHelper = this.tdCreateHelper.bind(this);
        this.buttonCreateHelper = this.buttonCreateHelper.bind(this);
        this.itineraryUpdateSelected = this.itineraryUpdateSelected.bind(this);
        //this.UpDownMove = this.UpDownMove.bind(this);
        this.UpMove=this.UpMove.bind(this);
        this.DownMove=this.DownMove.bind(this);
        this.state = {
            markers: [],
            markerNames: [],
            selected: [ "leg distance", "cumulative distance"],

            newPlace: {}


        };

    }

    itineraryUpdateSelected(newSelcted)
    {
        this.setState(
            {
                selected:newSelcted
            }
        )
    }

    RemoveItinerary(event) {
        let temp = this.props.itinerary.places;
        temp.splice(event.target.name, 1);
        this.props.updateItinerary("places", temp);
    }

    SetAsStart(event) {
        let temp = this.props.itinerary.places;
        let currntPlace = temp[event.target.name];
        temp.splice(event.target.name, 1);
        temp.unshift(currntPlace);
        this.props.updateItinerary("places", temp);
    }


    UpMove(event){

        let index  = parseInt(event.target.name)

        let temp = this.props.itinerary.places;
        let currntPlace= temp[index];
        let downPlace= temp[index-1];
        temp.splice(index-1, 1, currntPlace);
        temp[index] = downPlace;

        this.props.updateItinerary("places",temp);
    }


    DownMove(event){

        let index  = parseInt(event.target.name)

        let temp = this.props.itinerary.places;
        let currntPlace= temp[index];
        let downPlace= temp[index+1];
        temp.splice(index+1, 1, currntPlace);
        temp[index] = downPlace;

        this.props.updateItinerary("places",temp);
    }




    HandleOneMarker(event) {
        console.log("here in handleonmarker")
        let tt = this.props.itinerary.places;
        let currntPlace = tt[event.target.name];
        const index = this.props.markerNames.indexOf(event.target.value);
        let temp = this.props.markers;
        let tempName = this.props.markerNames;
        if (index < 0) {
            let newMarker = CreateOneMarker(currntPlace,currntPlace.name.toString());
            temp.push(newMarker);
            tempName.push(event.target.value)
        } else {
            temp.splice(index, 1);
            tempName.splice(index, 1);

        }
        this.setState({
            markers: temp,
            markerNames: tempName
        });
        this.props.updateMarker(temp, tempName);
    }


    buttonCreateHelper(bname, handler,index, keyud,pname)
    {

        let button =
            <Button  onClick={handler} size="sm" id={"oOutline"} name={index} type="button" color="outline-info" key ={keyud} value ={pname}>{bname}</Button>

        return button;
    }

    tdCreateHelper(name,index)
    {
        let td = (
            <td>
                <div>{name}</div>
                <div className="input-group-prepend">
                    {this.buttonCreateHelper("Remove",this.RemoveItinerary,index,"0",name)}
                    {this.buttonCreateHelper("Up",this.UpMove,index,"-1",name)}
                    {this.buttonCreateHelper("Down",this.DownMove,index,"1",name)}
                    {this.buttonCreateHelper("Set as Start",this.SetAsStart,index,"0",name)}
                    {this.buttonCreateHelper("Add/Delete Marker",this.HandleOneMarker,index,"0",name)}
                </div>
            </td>
        )
        return td;

    }

    getTableInfo() {
        let table = [];
        let total = 0;
        let places = this.props.itinerary.places;
        let distances = this.props.itinerary.distances;
        for (let j = 0; j < places.length; j++) {
            let oneline = [];
            oneline.push(this.tdCreateHelper(places[j].name,j));
            total += distances[j];

            for (let i = 0; i < this.state.selected.length; i++) {
                let attribute  = this.state.selected[i];
                if (places[j].hasOwnProperty(attribute))
                {
                        oneline.push(<td>{places[j][attribute]}</td>)
                }
                else if (this.state.selected[i] === "leg distance") {
                    oneline.push(<td>{distances[j]}</td>)
                }
                else if (this.state.selected[i] === "cumulative distance") {
                    oneline.push(<td>{total}</td>)
                }
                else {
                    oneline.push(<td>&nbsp;</td>)
                }
            }
            table.push(<tr>{oneline}</tr>)
        }
        return table;
    }



    render() {
        let con =  ["leg distance", "cumulative distance"];

        let selectors = <TableColSelector
            getTableInfo = {this.getTableInfo}
            serverConfig={this.props.serverConfig}
            initialselected={con}
            itineraryUpdateSelected ={this.itineraryUpdateSelected}
        />

        console.log("May9",this.props.serverConfig);

        return  <Pane header={'Select what to display for the itinerary results!'}
                      bodyJSX={selectors}
        />


    }
}


export function CreateOneMarker(currntPlace,name) {
    console.log("here in marker single")
    let Coordinates = require('coordinate-parser');
    let try1;
    let tempMarker;
    let lat;
    let long;
    try1 = new Coordinates(currntPlace.latitude.toString() + " " + currntPlace.longitude.toString());
    lat = try1.getLatitude()
    long = try1.getLongitude();
    tempMarker = new L.latLng(lat, long);

    return <Marker
        position={tempMarker}
        icon={markerIcon()}>
        <Popup>{name}</Popup>
    </Marker>
}

export function     markerIcon() {
    // react-leaflet does not currently handle default marker icons correctly,
    // so we must create our own
    return L.icon({
        iconUrl: icon,
        shadowUrl: iconShadow,
        iconAnchor: [12, 40]  // for proper placement
    })
}