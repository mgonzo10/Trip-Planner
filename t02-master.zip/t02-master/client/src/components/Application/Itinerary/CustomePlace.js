import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import { Label,InputGroup, InputGroupAddon, Input } from 'reactstrap'
import { Modal, ModalHeader, ModalBody, ModalFooter,Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import Pane from '../Pane';
import { Table } from 'reactstrap';
import { Form, FormGroup, FormText } from 'reactstrap';
import { Button, ButtonGroup } from 'reactstrap';
import {Map, Marker, Popup, TileLayer, Polyline, LayersControl} from 'react-leaflet';

export default class CustomePlace extends Component {
    constructor(props) {
        super(props);
        this.addCustomPlace = this.addCustomPlace.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.colCreateHelper = this.colCreateHelper.bind(this);

        this.toggle = this.toggle.bind(this);


        this.state = {

            newPlace:{},
            modalOpen: false

        };

    }


    toggle(event) {
        let name = event.target.name;
        this.setState({
            modalOpen: !this.state.modalOpen
        });
    }
    addCustomPlace(event){
        let temp = this.state.newPlace;
        temp[event.target.name] = event.target.value;
        this.setState({newPlace:temp});
        //console.log("check 1", event.target.value)

    }
    handleSubmit(event){
        console.log("check 2")
        let temp = this.props.itinerary.places;
        temp.push(this.state.newPlace);
        this.props.updateItinerary("places", temp);
        event.preventDefault();
    }

    colCreateHelper(label,tni,ph)
    {
        let rw = <Col md={6}>
            <FormGroup>
                <Label>
                    {label}
                </Label>
                <Input
                    type={tni}
                    name={tni}
                    id={tni}
                    placeholder={ph}
                    onChange={this.addCustomPlace}
                />
            </FormGroup>
        </Col>
        return rw;
    }
    render()
    {
        return <span>
                <Button onClick={this.toggle} color="outline-info">
                    Enter & Add your place!
                </Button>
                <Modal isOpen={this.state.modalOpen} toggle={this.toggle} name = "modalOpen"
                       size="lg"
                       aria-labelledby="contained-modal-title-vcenter"
                       centered
                >
                    <ModalBody>
                         <p> Enter your own place.</p>
                          <p>Click Submit botton to add it to your itinerary.</p>
                        {this.renderCP()}
                    </ModalBody>

                </Modal>
            </span>
    }
    renderCP(){
        return(
            <Pane
                header={"Add Your Own Place"}
                bodyJSX={
                    <Form>
                        <Row form>
                            {this.colCreateHelper("Name","name","Enter Name")}
                            {this.colCreateHelper("Latitude","latitude","Enter Latitude")}
                        </Row>
                        <Row form>
                            {this.colCreateHelper("Longitude","longitude","Enter Longitude")}
                            {this.colCreateHelper("ID","id","Enter ID")}
                        </Row>
                        <Row form>
                            {this.colCreateHelper("Municipality","municipality","Enter Municipality")}
                            {this.colCreateHelper("Altitude","altitude","Enter Altitude")}
                        </Row>
                        <Button
                            color="info"
                            type="submit"
                            onClick={this.handleSubmit}>
                            Submit
                        </Button>
                    </Form>

                }
            />
        );

    }






}