import React, { Component } from 'react'

import { Card, CardHeader, CardBody } from 'reactstrap'
import { Row, Col, Button, ButtonGroup } from 'reactstrap'
/*
    this.state = {
      serverConfig: null,
      planOptions: {
        units: {
          'miles':3959,
          'kilometers':6371,
          'nautical miles':3440,
          'user customized':0,

        },
          activeUnit: 'miles',
          userUnitName:''
      },
 */
/*
 updatePlanOption(option, value) {
    let optionsCopy = Object.assign({}, this.state.planOptions);
    optionsCopy[option] = value;
    this.setState({'planOptions': optionsCopy});
  }
 */
export default class Units extends Component {
    constructor(props) {
        super(props);
        this.state=
            {
                units: {
                    'miles':3959,
                    'kilometers':6371,
                    'nautical miles':3440,
                    'user customized':null,

                },

                newUnitName:' ',
                newUnitRadius:0,

                activeUnit: 'miles'

            };


            this.renderUnitButtons=this.renderUnitButtons.bind(this);
        this.handleFirst=this.handleFirst.bind(this);
        this.handleRadius= this.handleRadius.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
            this.handleUnit=this.handleUnit.bind(this);
    this.makeUserInput=this.makeUserInput.bind(this);

    }

    render() {
        return(
            <div>
                <Card className='text-center'>
                    <CardHeader className='bg-csu-gold text-white font-weight-semibold'>Units</CardHeader>
                    <CardBody>
                        <ButtonGroup vertical className='w100'>
                            {this.renderUnitButtons(Object.keys(this.props.options.units))}

                        </ButtonGroup>
                    </CardBody>
                </Card>
                {this.makeUserInput()}
            </div>
        );
    }


//yousilule change the user costumized filed,using this.props.updateOption('activeUnit', event.target.value)


    renderUnitButtons(names) {


        return names.sort().map((unit) =>

            {

                if(unit==='user customized')
                {
                    return <Button
                        className='btn-csu w-100 text-left'
                        key={"button_"+unit}
                        active={this.props.activeUnit === unit}
                        value={unit}
                        onClick={this.handleFirst}
                    >
                        {unit.charAt(0).toUpperCase() + unit.slice(1)}
                    </Button>






                }

                else return <Button
                    className='btn-csu w-100 text-left'
                    key={"button_"+unit}
                    active={this.props.activeUnit === unit}
                    value={unit}
                    onClick={(event) => this.props.updateOption('activeUnit', event.target.value)}
                >
                    {unit.charAt(0).toUpperCase() + unit.slice(1)}
                </Button>




            }

        );
    }



/* handleUnit(event){
        this.props.updateOption('userUnitName', event.target.value);
        event.preventDefault();
    handleRadius(event){
        let n =null;

        let ty = event.target.name
        if(ty=== "unitsname")
            n= {
                units: {
                    'miles': 3959,
                    'kilometers': 6371,
                    'nautical miles': 3440,
                    [ty]: 0

                }
            }
        else{
            n= {
                units: {
                    'miles': 3959,
                    'kilometers': 6371,
                    'nautical miles': 3440,
        : 0

        }
        }
        }
*/


        handleFirst(event)
        {
            let c = 'user customized';
            this.setState({activeUnit:c });


        }


        handleUnit(event)
        {
            this.setState({newUnitName: event.target.value});
            this.props.updateOption('activeUnit', event.target.value);
            event.preventDefault();

        }

        handleRadius(event)
        {

            this.setState({newUnitRadius: event.target.value});
            event.preventDefault();
        }

        handleSubmit(event)
        {

            let temp=Object.assign({},this.state.units);
           // temp[this.state.newUnitName] = this.state.newUnitRadius;
           // let r = {};
           // r.units=temp;
           // r.activeUnit=this.state.newUnitName;


            temp[this.state.newUnitName] = this.state.newUnitRadius;
           // temp[this.state.activeUnit]=this.state.newUnitName;

            console.log("here is temp");
            console.log(temp);

            this.setState({units:temp});
            console.log("after assinging. the units itself in state"+ this.state.units);
            console.log(this.state.units);
            this.props.updateOption('units', temp);
           /* this.props.updateOption('units', this.state.units);
            this.props.updateOption('activeUnit', this.state.newUnitName);*/

            console.log("print out the props.options");
            console.log(this.props.options);

            alert("Success, radius set to: "+this.state.newUnitName );
            event.preventDefault();
        }

    makeUserInput()
        {

            if(this.state.activeUnit === 'user customized')

            return  <form onSubmit={this.handleSubmit}>
                    <label>
                        <form>
                            Unit Name:
                            <input type="text" placeholder={"name"} onChange={this.handleUnit} />
                            Earth Radius:
                            <input type = "text" placeholder={"radius"} onChange={this.handleRadius}/>
                        </form>
                    </label>
                    <input type="submit" value="Submit" />
                </form>;
        }















}
