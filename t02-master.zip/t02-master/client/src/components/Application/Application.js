import React, {Component} from 'react';
import {Card, CardBody, CardHeader, Container} from 'reactstrap';
import Home from './Home';
import Options from './Options/Options';
import Calculator from './Calculator/Calculator';
import Settings from './Settings/Settings';
import About from './About/About';
import {getOriginalServerPort, sendServerRequest} from '../../api/restfulAPI';
import ErrorBanner from './ErrorBanner';
import Itinerary from "./Itinerary/Itinerary";


/* Renders the application.
 * Holds the destinations and options state shared with the trip.
 */
export default class Application extends Component {
  constructor(props){
    super(props);

    this.updatePlanOption = this.updatePlanOption.bind(this);
    this.updateClientSetting = this.updateClientSetting.bind(this);
    this.createApplicationPage = this.createApplicationPage.bind(this);
    this.updateResponse = this.updateResponse.bind(this);
      this.addPlace = this.addPlace.bind(this);
      this.updateItinerary = this.updateItinerary.bind(this);
      this.updateFind = this.updateFind.bind(this);


      this.state = {
      serverConfig: null,
      planOptions: {
        units: {
          'miles':3959,
          'kilometers':6371,
          'nautical miles':3440,
          'user customized':null},
          activeUnit: 'miles'
      },
      itinerary: {
          'requestType'    : 'itinerary',
          'requestVersion' : 3,

          'options'        : {
              'optimizations':'none'

          },

          'places'         : [],
          'distances'      : []
      },

      find: {
       "requestType"    : "find",
       "requestVersion" : 3,
       "match"          : "",
          "narrow"      :[],
       "limit"          : 0,
       "found"          : 0,
       "places"         : []
       },

      clientSettings: {
        serverPort: getOriginalServerPort()
      },
      errorMessage: null
    };

    this.updateServerConfig();
  }

  render() {
    let pageToRender = this.state.serverConfig ? this.props.page : 'settings';

    return (
      <div className='application-width'>
        { this.state.errorMessage }{ this.createApplicationPage(pageToRender) }
      </div>
    );
  }

  updateClientSetting(field, value) {
    if(field === 'serverPort')
      this.setState({clientSettings: {serverPort: value}}, this.updateServerConfig);
    else if(field === 'clientSettings'){
        let newSettings = Object.assign({}, this.state.planOptions);
        newSettings[field] = value;
        this.setState({clientSettings: newSettings});
    }
  }




    addPlace(place) {
        console.log("add place,", place);
        let testTrip = Object.assign({}, this.state.itinerary);
        testTrip.places.push(place);
        //console.log(testTrip);
        this.setState({itinerary:testTrip});
    }



    updateItinerary(option, value) {
        let itineraryCopy = Object.assign({}, this.state.itinerary);
        itineraryCopy[option] = value;


        this.setState({itinerary: itineraryCopy});
        console.log(this.state.itinerary)
    }

    updateFind(option, value) {
        let FindCopy = Object.assign({}, this.state.find);
        FindCopy[option] = value;


        this.setState({find: FindCopy});
        console.log(this.state.find)
    }



    updatePlanOption(option, value) {
    let optionsCopy = Object.assign({}, this.state.planOptions);
    optionsCopy[option] = value;
    console.log("updating the plan option, firt the value, then the optionsCOPY");
    console.log(value);
      console.log(optionsCopy);
      console.log("print out the state of the parent this.state.planOptions");
      console.log(this.state.planOptions);



      this.setState({planOptions: optionsCopy});
  }

  updateServerConfig() {
    sendServerRequest('config', this.state.clientSettings.serverPort).then(config => {
      console.log(config);
      this.processConfigResponse(config);
    });
  }

  createErrorBanner(statusText, statusCode, message) {
    return (
      <ErrorBanner statusText={statusText}
                   statusCode={statusCode}
                   message={message}/>
    );
  }

  updateResponse(value){
    this.setState({itinerary: value})
    //console.log(this.state.itinerary);
  }
  getSetting(){
    return this.state.itinerary;
  }
  createApplicationPage(pageToRender) {
    switch(pageToRender) {
      case 'calc':
        return <Calculator options={this.state.planOptions}
                           settings={this.state.clientSettings}
                           createErrorBanner={this.createErrorBanner}/>;
      case 'options':
        return <Options options={this.state.planOptions}
                        config={this.state.serverConfig}
                        updateOption={this.updatePlanOption}/>;

      case 'settings':
        return <Settings settings={this.state.clientSettings}
                         serverConfig={this.state.serverConfig}
                         updateSetting={this.updateClientSetting}/>;
      case 'about':
        return <About />;
      case 'itinerary':
        return <Itinerary settings={this.state.clientSettings}
                          options={this.state.planOptions}
                          serverConfig={this.state.serverConfig}
                          updateSetting={this.updateClientSetting}
                          getSetting={this.getSetting}
                          updateClientSettings={this.updateClientSetting}
                          updateResponse={this.updateResponse}
                          itinerary={this.state.itinerary}
                          find={this.state.find}
                          addPlace={this.addPlace}
                          updateItinerary={this.updateItinerary}
                          updateFind={this.updateFind}
                          createErrorBanner={this.createErrorBanner}
                          //addCustomPlace={this.addCustomPlace}
             />;
      default:
        return <Home/>;
    }
  }

  processConfigResponse(config) {
    if(config.statusCode >= 200 && config.statusCode <= 299) {
      console.log("Switching to server ", this.state.clientSettings.serverPort);
      this.setState({
        serverConfig: config.body,
        errorMessage: null
      });
    }
    else {
      this.setState({
        serverConfig: null,
        errorMessage:
          <Container>
            {this.createErrorBanner(config.statusText, config.statusCode,
            `Failed to fetch config from ${ this.state.clientSettings.serverPort}. Please choose a valid server.`)}
          </Container>
      });
    }
  }
}
