import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import { Button } from 'reactstrap'
import { Form, Label, Input } from 'reactstrap'
import { sendServerRequestWithBody } from '../../../api/restfulAPI'
import Pane from '../Pane';
import pic from './images/JoelImage.jpg';
import logo from './images/maritza_pic.jpg';
import logoWM from './images/IMG_wenrui.jpg';
import logoLI from './images/li.jpg';




export default class About extends Component {
    constructor(props) {
        super(props);

        this.state = {
            serverConfig: null,
            errorMessage: null
        };
    }

    render() {
        return (
            <Container>
                { this.state.errorMessage }
                <Row>
                    <Col>
                        {this.header()}
                    </Col>
                </Row>
                <Row>
                    <Col xs={12} sm={6} md={4} lg={3}>
                        <img src={logo} alt="maritza"/>
                        {this.maritzaBio('maritza gonzalez')}
                    </Col>
                    <Col xs={12} sm={6} md={4} lg={3}>
                        <img src={pic} alt= "Joel"/>
                        {this.joelBio('joel topps')}
                    </Col>
                    <Col xs={12} sm={6} md={4} lg={3}>
                        <img src={logoWM} alt="wenrui"/>
                        {this.maBio('wenrui ma')}
                    </Col>
                    <Col xs={12} sm={6} md={4} lg={3}>
                        <img src={logoLI} alt="wenhao"/>
                        {this.liBio('wenhao li')}
                    </Col>
                </Row>
            </Container>
        );
    }

    header() {
        return(
            <Pane header={'About Us!'}
                  bodyJSX={'Learn more about everyone on The TwoTwos.'}/>
    );
    }


    joelBio(){
        return(
            <Pane header={'Joel Topps'}
                bodyJSX={"My name is Joel an I'm from Beavercreek Ohio. I am a Junior Computer Science major and Air Force ROTC cadet at Colorado State University. I really enjoy being active in the outdoors especially if Im hunting, skiing, or playing lacrosse. When I graduate, I hope to become a pilot in the Air Force flying my favorite aircraft, the A-10 Warthog."}/>
        );
    }
    maritzaBio(){
        return(
            <Pane header={'Maritza Gonzalez'}
                  bodyJSX={"Hi I'm Maritza. I'm from El Paso, TX but have lived in Colorado for half my life. I play tennis and love dogs.  My other hobbies include cooking but mostly eating.  My favorite food is doughnuts"}/>
        );
    }
    maBio(){
        return(
            <Pane header={'Wenrui Ma'}
                  bodyJSX={'I am Wenrui Ma, a Chinese student majoring in Computer Science. This is my fourth and also my final semester here at CSU. I am broadly interested in all fields of Computer Science.'}/>
        );
    }
    liBio(){
        return(
            <Pane header={'Wenhao Li'}
                  bodyJSX={"My name is Wenhao Li. I'm a Junior student majoring in Computer Science. I'm a transfer student from Shanghai and this is my first year in U.S. I hope I can enjoy my time living in Fort Collins!"}/>
        );
    }

}