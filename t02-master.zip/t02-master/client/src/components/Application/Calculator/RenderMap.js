import {Col, Container, Row} from "reactstrap";
import {LayersControl, Map, Marker, Polyline, Popup, TileLayer} from "react-leaflet";
import React, {Component} from 'react';
import L from "leaflet";
import MapMarker from '../Itinerary/MapMarker';
import {CreateOneMarker, markerIcon} from '../Itinerary/TableItinerary'

export default class RenderMap extends Component {


    constructor(props){
        super(props);
        this.state={
            itinerary :[],
            markers:[]
        }


    }
    render() {
        return (
            <Container>
                <Row>
                    <Col>
                    {this.renderMap()}
                    </Col>
                </Row>
            </Container>
        );
    }
simpleParserForLine(currntPlace)
{
    let Coordinates = require('coordinate-parser');
    let try1;
    let tempMarker;
    let lat;
    let long;
    try1 = new Coordinates(currntPlace.latitude.toString() + " " + currntPlace.longitude.toString());
    lat = try1.getLatitude()
    long = try1.getLongitude();
    tempMarker = new L.latLng(lat, long);
    return tempMarker;
}



    renderMap(){
        let stuff = [];
        let markers=[];



        if(this.props.origin.latitude!=="" && this.props.origin.longitude!==""){
           try{
               stuff.push(this.simpleParserForLine(this.props.origin));
               console.log("stuff0",stuff[0])
               let tempMarker=CreateOneMarker(this.props.origin,"Origin");
               markers.push(tempMarker)
           }
           catch(err)
           {
                stuff = [];
                markers=[];
           }
        }

        if(this.props.destination.latitude!=="" && this.props.destination.longitude!==""){
           try{
               stuff.push(this.simpleParserForLine(this.props.destination));
               let tempMarker=CreateOneMarker(this.props.destination,"Destination");
               markers.push(tempMarker)
           }
           catch(err)
           {
               stuff = [];
               markers=[];
           }
        }
        {console.log("lList",stuff)}
        return (<MapMarker
            itinerary={this.state.itinerary}
            markers = {this.state.markers}
                   disl={stuff}
                   dism = {markers}
        />)
    }





}