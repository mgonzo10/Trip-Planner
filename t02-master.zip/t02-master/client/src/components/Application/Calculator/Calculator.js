import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import { Button } from 'reactstrap'
import { Form, Input } from 'reactstrap'
import { sendServerRequestWithBody } from '../../../api/restfulAPI'
import Pane from '../Pane';
import Cookies from '../Cookies/Cookies';
import { toDMC,toLatLon, } from 'coordinate-parser';
import  Coordinates  from 'coordinate-parser';
import * as schema from '../../../../../server/src/main/resources/TIPDistanceSchema.json';
import RenderMap from './RenderMap';




export default class Calculator extends Component {

  constructor(props) {
    super(props);

    this.updateLocationOnChange = this.updateLocationOnChange.bind(this);
    this.calculateDistance = this.calculateDistance.bind(this);
    this.createInputField = this.createInputField.bind(this);

    //this.calCookie=new Cookies();

    let localData=Cookies.getCookie("position");// Try to get the cookie

    Cookies.deleteCookie("position");
    if(localData===""){//If there is no saved cookie
        this.state = {
          origin: {latitude: '', longitude: ''},
          destination: {latitude: '', longitude: ''},
          distance: 0,
          errorMessage: null,
            decimalOrigin:null,
            decimalDest:null,

        };
    }
    else{ //If this is not the first time visiting, which means we have the saved cookie
        this.state=JSON.parse(localData);
        if(this.state.origin.latitude!==''&&this.state.origin.longitude!==''
            &&this.state.destination.latitude!==''&&this.state.destination.longitude!=='')
                this.calculateDistance();
    }

  }

  render() {
      //console.log(this.state);
    return (
      <Container>
        { this.state.errorMessage }
        <Row>
          <Col>
            {this.createHeader()}
          </Col>
        </Row>
          <Row>
              <Col>
                  <RenderMap origin={this.state.destination}
                             destination={this.state.origin}
                  />
              </Col>
          </Row>
        <Row>
          <Col xs={12} sm={6} md={4} lg={3}>
            {this.createForm('origin')}
          </Col>
          <Col xs={12} sm={6} md={4} lg={3}>
            {this.createForm('destination')}
          </Col>
          <Col xs={12} sm={6} md={4} lg={3}>
            {this.createDistance()}
          </Col>
        </Row>
      </Container>
    );
  }

  createHeader() {
    return (
        <Pane header={'Calculator'}
              bodyJSX={
                  <div>
                  Determine the distance between the origin and destination. Change the units on the <b>Options</b> page.
                  </div>
              }/>
    );
  }

  createInputField(stateVar, coordinate) {
    let updateStateVarOnChange = (event) => {
      this.updateLocationOnChange(stateVar, event.target.name, event.target.value)};

    let capitalizedCoordinate = coordinate.charAt(0).toUpperCase() + coordinate.slice(1);
    return (
      <Input name={coordinate} placeholder={capitalizedCoordinate}
             id={`${stateVar}${capitalizedCoordinate}`}
             value={this.state[stateVar][coordinate]}
             onChange={updateStateVarOnChange}
             style={{width: "100%"}} />
    );

  }

  createForm(stateVar) {
    return (
      <Pane header={stateVar.charAt(0).toUpperCase() + stateVar.slice(1)}
            bodyJSX={
              <Form >
                {this.createInputField(stateVar, 'latitude')}
                {this.createInputField(stateVar, 'longitude')}
              </Form>
            }
      />);
  }

  createDistance() {
      return(
          <Pane header={'Distance'}
                bodyJSX={
                    <div>
                        <h5>{this.state.distance} {this.props.options.activeUnit}</h5>
                        <Button onClick={this.calculateDistance}>Calculate</Button>
                    </div>}
          />
      );
  }

  calculateDistance() {
        let Coordinates = require('coordinate-parser');
        let try1 = new Coordinates(this.state.origin.latitude.toString() + " " + this.state.origin.longitude.toString());
        let try2 = new Coordinates(this.state.destination.latitude.toString() + " " + this.state.destination.longitude.toString());
        let lat1 = try1.getLatitude();
        lat1 = lat1.toString();
        let long1 = try1.getLongitude();
        long1 = long1.toString();
        let lat2 = try2.getLatitude();
        lat2 = lat2.toString();
        let long2 = try2.getLongitude();
        long2 = long2.toString();
        let originDecimal={
            'latitude' : lat1,// 40.123 ✓
            'longitude'  : long1, // -74.123 ✓
        };


        let dstDecimal={
            'latitude' : lat2,// 40.123 ✓
            'longitude'  : long2, // -74.123 ✓
        }


        console.log("origin")
        console.log(originDecimal)
        console.log("des")

        console.log(dstDecimal)

      this.setState({
          decimalOrigin:originDecimal,
          decimalDest:dstDecimal,
      })


      let radius = this.props.options.units[this.props.options.activeUnit];

    const tipConfigRequest = {
      'requestType'        : 'distance',
      'requestVersion'     : 4,
        'origin'      :  Object.assign({}, originDecimal),
        'destination' :  Object.assign({}, dstDecimal),
      'earthRadius' : parseInt(radius)
    };

      console.log(" the request from client of the calculator!!!!!!!!!");
      console.log(tipConfigRequest);

    sendServerRequestWithBody('distance', tipConfigRequest, this.props.settings.serverPort)
      .then((response) => {
          let Ajv = require('ajv');
          let ajv = new Ajv(); // options can be passed, e.g. {allErrors: true}
          let validate = ajv.compile(schema);
          let valid = validate(response.body);
          //console.log(valid);
          if(valid == false){
              response.statusCode= 400;
              this.setState({
                  errorMessage: this.props.createErrorBanner(
                      response.statusText,
                      response.statusCode,
                      `Request to ${ this.props.settings.serverPort } failed.`
                  )
              });
          }
          console.log(response.statusCode);
          //console.log(" the response from server of the calculator !!!!!!!!!");
          console.log(response);
        if(response.statusCode >= 200 && response.statusCode <= 299) {
          this.setState({
            distance: response.body.distance,
            errorMessage: null
          });
          Cookies.setCookie("position",JSON.stringify(this.state),1);
        }
        else {
            if (response.statusCode === 400) {
                console.log("here we are 400 in calculator.js")
                this.setState({
                    errorMessage: this.props.createErrorBanner(
                        response.statusText,
                        response.statusCode,

                        `Please enter valid lat/long parameters!`
                    )
                });
            }
            else {
                this.setState({
                    errorMessage: this.props.createErrorBanner(
                        response.statusText,
                        response.statusCode,
                        `Request to ${ this.props.settings.serverPort } failed.`
                    )
                });
            }
        }
      });
  }

  updateLocationOnChange(stateVar, field, value) {
    let location = Object.assign({}, this.state[stateVar]);
    location[field] = value;
    this.setState({[stateVar]: location});

    Cookies.setCookie("position",JSON.stringify(this.state),1);
  }
}
