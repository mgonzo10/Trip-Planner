import './enzyme.config.js';
import React from 'react';
import {mount,shallow} from 'enzyme';
import Find from '../src/components/Application/Itinerary/Find';


const startProperties = {

   "serverConfig":
       {
       "requestType"        : "config",
       "requestVersion"     : 4,
       "serverName"         : "t02 the two twos",
       "placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude"],
       "optimizations"      : ["none", "short", "shorter"],
       "filters"            : [{"name": "type",
           "values": ["airport","heliport","balloonport","closed"]}
       ]
   }



};


function testCreateInputFields() {
    const find = mount((
        <Find
            serverConfig={startProperties.serverConfig}
            itinerary={startProperties.itinerary}

        />
    ));

    let numberOfInputs = find.find('Filter').length;
    expect(numberOfInputs).toEqual(0);

}

test('Testing the  how many filter function in find', testCreateInputFields);
function testTableColSelector() {
    const find = mount((
        <Find
            serverConfig={startProperties.serverConfig}
            itinerary={startProperties.itinerary}

        />
    ));

    let numberOfInputs = find.find('TableColSelector').length;
    expect(numberOfInputs).toEqual(0);

}

test('Testing the  how many TableColSelector function in find', testTableColSelector);


function testsanitizeInput() {
    const find = mount((
        <Find
            serverConfig={startProperties.serverConfig}
            itinerary={startProperties.itinerary}

        />
    ));

    let badInput ="denver*&*&*"
    let actualResult = find.instance().sanitizeInput(badInput);

    expect(actualResult).toEqual("denver_");

}

test('Testing the  sanitizeInput in find', testsanitizeInput);

function testMoresanitize(){
    const find = mount((
        <Find
            serverConfig={startProperties.serverConfig}
            itinerary={startProperties.itinerary}

        />
    ));

    let badInput ="denver****"
    let actualResult = find.instance().sanitizeInput(badInput);

    expect(actualResult).toEqual("denver_");
}
//"name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude"


function testButtonForTableDisplay() {
    const exampleComponent = mount( <Find
        serverConfig={startProperties.serverConfig}
        itinerary={startProperties.itinerary}

    />);
    let exptecttedSelect =["id","municipality"];

    let initialToggleValue = exampleComponent.state().selected;
    expect(initialToggleValue).toEqual(exptecttedSelect);

//wrapper.find({ foo: 3 });
    let numberOfInputs  = exampleComponent.find({type:"checkbox"}).length

    expect(numberOfInputs).toEqual(0);


}
test('Testing the buttons for choosing what to display for the find result table', testButtonForTableDisplay);




function testButtonForTableDisplayAddState() {
    const exampleComponent = mount( <Find
        serverConfig={startProperties.serverConfig}
        itinerary={startProperties.itinerary}

    />);
    let exptecttedSelect =["id","municipality"];

    let initialToggleValue = exampleComponent.state().selected;
    expect(initialToggleValue).toEqual(exptecttedSelect);
//wrapper.find({ foo: 3 });

    let event = {target: {name: "name", value: "name"}};

    //let temp  = exampleComponent.find({name:"latitude"}).at(0)
    let tt  = exampleComponent.find("TableColSelector").at(0)
    let temp  = tt.find({name:"latitude"}).at(0)

   // simulateOnClick(temp, exampleComponent);
    let afterclickname = exampleComponent.state().selected;
    let exptecttedSelect2 =["id","municipality","latitude"];

    expect(exptecttedSelect2).toEqual(exptecttedSelect2);



}

function simulateOnClick(button, parentWrapper) {

    button.simulate('change');
    parentWrapper.update();
}

test('Testing the buttons for choosing what to display for the find result table, see if the state changes according to that', testButtonForTableDisplayAddState);




function testButtonForTableDisplayDeleteState() {
    const renderMock = jest.fn();

    const exampleComponent = mount( <Find
        serverConfig={startProperties.serverConfig}
        itinerary={startProperties.itinerary}

    />);
    let exptecttedSelect =["id","municipality"];

    let initialToggleValue = exampleComponent.state().selected;
    expect(initialToggleValue).toEqual(exptecttedSelect);
//wrapper.find({ foo: 3 });


    let temp  = exampleComponent.find("TableColSelector").at(0)

   // simulateOnClick(temp, exampleComponent);
    let afterclickname = exampleComponent.state().selected;
    let exptecttedSelect2 =["municipality"];

    expect(exptecttedSelect2).toEqual(exptecttedSelect2);



}

function simulateOnClick(button, parentWrapper) {

    button.simulate('change');
    parentWrapper.update();
}

test('Testing the buttons for choosing what to display for the find result table, see if the state changes according to that', testButtonForTableDisplayDeleteState);





