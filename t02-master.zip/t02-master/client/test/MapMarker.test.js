import './enzyme.config.js'
import React from 'react'
import { shallow, mount } from 'enzyme'
import MapMarker from '../src/components/Application/Itinerary/MapMarker'

const startProperties = {
    'options': {
        'units': {'miles': 3959, 'kilometers': 6371},
        'activeUnit': 'miles',
        'serverPort': 'black-bottle.cs.colostate.edu:31400'
    },
    'itinerary': {
        'requestType'    : 'itinerary',
        'requestVersion' : 3,
        'options'        : {

        },
        'places'         : [],
        'distances'      : []
    },
    'serverConfig':{
        "requestType"        : "config",
        "requestVersion"     : 3,
        "serverName"         : "t02 ",
        "placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "altitude"],
        "optimizations"      : ["none","short"]
    }


};

function testMapMarkerrender() {
    const testMapMarker = shallow(
     (<MapMarker
            itinerary={startProperties.itinerary}
            markers = {[]}
            disl={[]}
            dism = {[]}
        />));

    expect(testMapMarker.find("Map").length).toEqual(1);
}
test('Testing to see if everything renders correctly with Itinerary', testMapMarkerrender);

function testMaprender() {
    const testMapMarker = shallow(
        (<MapMarker
            itinerary={startProperties.itinerary}
            markers = {[]}
            disl={[]}
            dism = {[]}
        />));

    expect(testMapMarker.find("BaseLayer").length).toEqual(6);
}
test('Testing to see if everything renders correctly with Itinerary', testMaprender);


