import './enzyme.config.js'
import React from 'react'
import { shallow,mount } from 'enzyme'
import App from '../src/components/App'
import Header from '../src/components/Margins/Header';
import Navigation from '../src/components/Margins/Navigation';
import Application from '../src/components/Application/Application';
import Footer from '../src/components/Margins/Footer';



function testApp() {
    const app = mount(<App/>);
    //app.instance().pages.size()

    expect(app.instance().pages.length).toEqual(6);
    expect(app.instance().pages[0]).toEqual({"page": "", "title": "T02 The TwoTwos"});
    expect(app.instance().pages[1]).toEqual({ title: 'About', page: 'about'});
    expect(app.instance().pages[2]).toEqual({"page": 'calc', "title": 'Calculator'});
    app.instance().setAppPage({"page": 'test', "title": 'Test'});
    expect(app.instance().state.current_page).toEqual({"page": 'test', "title": 'Test'});
    expect(app.contains((
        <div className="csu-branding">
            <Header pages={this.pages} setAppPage={this.setAppPage}/>
            <Navigation pages={this.pages} setAppPage={this.setAppPage}/>
            <Application page={app.state.current_page}/>
            <Footer/>
        </div>
    )))
}

test("Testing App", testApp);