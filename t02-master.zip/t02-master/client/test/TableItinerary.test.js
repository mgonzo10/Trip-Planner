import './enzyme.config.js'
import React from 'react'
import { shallow, mount } from 'enzyme'
import TableItinerary, {CreateOneMarker} from '../src/components/Application/Itinerary/TableItinerary'
import {Col} from "reactstrap";
import Pane from '../src/components/Application/Pane'
import L from "leaflet";
const startProperties = {
    'itinerary':{name: "Adams County", latitude: "39.87", longitude: "-104.33", id: "1"},
    'origin':{latitude:3,longitude:'4'},
    'destination':{latitude:'3',longitude:'4'}
};

function testTableItinerary() {
    const tableItinerary = shallow(
        (<TableItinerary
            itinerary={startProperties.itinerary}
            markers = {[]}
            disl={[]}
            dism = {[]}
        />));
    expect(tableItinerary.contains(<Pane header={'Select what to display for the itinerary results!'}/>)).toEqual(false);
    //expect(tableItinerary.find("Map").length).toEqual(1);
}
test('Testing TableItinerary', testTableItinerary);


