import './enzyme.config.js'
import React from 'react'
import { shallow, mount } from 'enzyme'
import Download from '../src/components/Application/Itinerary/Download'

const startProperties= {
    'options': {
        'units': {'miles': 3959, 'kilometers': 6371},
        'activeUnit': 'miles',
        'serverPort': 'black-bottle.cs.colostate.edu:31400',
        "placeAttributes": ["name", "latitude", "longitude", "id", "municipality", "altitude"],
    },
        'serverConfig': {
            "requestType": "config",
            "requestVersion": 3,
            "serverName": "t02 ",
            "placeAttributes": ["name", "latitude", "longitude", "id", "municipality", "altitude"],
            "optimizations": ["none", "short"]
        },

        'itinerary': {
            'requestType': 'itinerary',
            'requestVersion': 3,
            'options': {},
            'places': [],

        },

}
function testChildExistsRender() {
    const testDownload = shallow(<Download serverConfig={startProperties.serverConfig}
                                           itinerary={startProperties.itinerary}



    />);

    expect(testDownload.find("Find").length).toEqual(0);
}
test('PlaceHolder', testChildExistsRender);

function testPaneRender() {
    const testDownload = shallow(<Download serverConfig={startProperties.serverConfig}
                                           itinerary={startProperties.itinerary}



    />);
    expect(testDownload.find("Pane").length).toEqual(0);
}
test('Test to ensure Pane renders', testPaneRender);

