import './enzyme.config.js'
import React from 'react'
import { shallow, mount } from 'enzyme'
import CustomePlace from '../src/components/Application/Itinerary/CustomePlace'

const startProperties = {
    'options': {
        'units': {'miles': 3959, 'kilometers': 6371},
        'activeUnit': 'miles',
        'serverPort': 'black-bottle.cs.colostate.edu:31400'
    },
    'itinerary': {
        'requestType'    : 'itinerary',
        'requestVersion' : 3,
        'options'        : {

        },
        'places'         : [],
        'distances'      : []
    },
    'serverConfig':{
        "requestType"        : "config",
        "requestVersion"     : 3,
        "serverName"         : "t02 ",
        "placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "altitude"],
        "optimizations"      : ["none","short"]
    }


};

function testFormExistsRender() {
    const testCustomPlace = shallow(<CustomePlace
                                            newPlace={{}}
                                            itinerary={startProperties.itinerary}
                                            modalOpen={false}
    />);

    expect(testCustomPlace.find("Form").length).toEqual(0);
}
test('Testing to see if everything renders correctly with Custom places', testFormExistsRender);

function testFormGroupsExistsRender() {
    const testCustomPlace = shallow(<CustomePlace
        newPlace={{}}
        itinerary={startProperties.itinerary}
        modalOpen={false}
    />);

    expect(testCustomPlace.find("FormGroup").length).toEqual(0);
}
test('Testing to see if formgroup renders correctly with Custom places', testFormGroupsExistsRender);

function testModalBodyRender() {
    const testCustomPlace = shallow(<CustomePlace
        newPlace={{}}
        itinerary={startProperties.itinerary}
        modalOpen={false}
    />);

    expect(testCustomPlace.find("ModalBody").length).toEqual(1);
}
test('Testing to see if modalbody renders correctly with Custom places', testModalBodyRender);


function testPaneRender() {
    const testCustomPlace = shallow(<CustomePlace
        newPlace={{}}
        itinerary={startProperties.itinerary}
        modalOpen={false}
    />);

    expect(testCustomPlace.find("Pane").length).toEqual(1);
}
test('Testing to see if pane renders correctly with Custom places', testPaneRender);
