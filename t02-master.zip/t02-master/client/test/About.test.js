import './enzyme.config.js'
import React from 'react'
import { shallow } from 'enzyme'
import About from '../src/components/Application/About/About'

import Pane from '../src/components/Application/Pane';



function testRender() {
    const about = shallow(<About/>);


    expect(about.contains(<Pane header={'About Us!'}
                                bodyJSX={'Learn more about everyone on The TwoTwos.'}/>
    )).toEqual(true);
    expect(about.contains(<Pane header={'Joel Topps'}
                                bodyJSX={"My name is Joel an I'm from Beavercreek Ohio. I am a Junior Computer Science major and Air Force ROTC cadet at Colorado State University. I really enjoy being active in the outdoors especially if Im hunting, skiing, or playing lacrosse. When I graduate, I hope to become a pilot in the Air Force flying my favorite aircraft, the A-10 Warthog."}/>
    )).toEqual(true);
    expect(about.contains(<Pane header={'Maritza Gonzalez'}
                                bodyJSX={"Hi I'm Maritza. I'm from El Paso, TX but have lived in Colorado for half my life. I play tennis and love dogs.  My other hobbies include cooking but mostly eating.  My favorite food is doughnuts"}/>
    )).toEqual(true);
    expect(about.contains(<Pane header={'Wenrui Ma'}
                                bodyJSX={'I am Wenrui Ma, a Chinese student majoring in Computer Science. This is my fourth and also my final semester here at CSU. I am broadly interested in all fields of Computer Science.'}/>
    )).toEqual(true);
    expect(about.contains(<Pane header={'Wenhao Li'}
                                bodyJSX={"My name is Wenhao Li. I'm a Junior student majoring in Computer Science. I'm a transfer student from Shanghai and this is my first year in U.S. I hope I can enjoy my time living in Fort Collins!"}/>
    )).toEqual(true);
}

test("Testing to see if an Pane component is rendered", testRender);