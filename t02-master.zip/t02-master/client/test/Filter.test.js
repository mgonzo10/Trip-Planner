import './enzyme.config.js';
import React from 'react';
import {mount,shallow} from 'enzyme';
import Filter from '../src/components/Application/Itinerary/Filter';


const startProperties = {

    "serverConfig":
        {
            "requestType"        : "config",
            "requestVersion"     : 4,
            "serverName"         : "t02 the two twos",
            "placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude"],
            "optimizations"      : ["none", "short", "shorter"],
            "filters"            : [{"name": "type",
                "values": ["airport","heliport","balloonport","closed"]}
            ]
        }



};


function testCreateInputFields() {
    const filter = mount((
        <Filter
            serverConfig={startProperties.serverConfig}
            itinerary={startProperties.itinerary}

        />
    ));

    let numberOfInputs = filter.find('Button').length;
    expect(numberOfInputs).toEqual(5);

}

test('Testing the  how many button for filter  in filter', testCreateInputFields);





//"name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude"





function testButtonForTableDisplayAddState() {
    const exampleComponent = mount( <Filter
        serverConfig={startProperties.serverConfig}
        itinerary={startProperties.itinerary}

    />);

    let exptecttedSelect =[];

    let initialToggleValue = exampleComponent.state().cSelected;
    expect(initialToggleValue).toEqual(exptecttedSelect);

//wrapper.find({ foo: 3 });
    let temp  = exampleComponent.find('Button').at(0)

    simulateOnClick(temp, exampleComponent);

    let afterclickname = exampleComponent.state().cSelected;
    let exptecttedSelect2 =["airport"];

    expect(afterclickname).toEqual(exptecttedSelect2);



}

function simulateOnClick(button, parentWrapper) {

    button.simulate('click');
    parentWrapper.update();
}

test('Testing the buttons for choosing what to display for the find result table, see if the state changes according to that', testButtonForTableDisplayAddState);


