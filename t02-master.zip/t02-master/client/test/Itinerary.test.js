import './enzyme.config.js'
import React from 'react'
import { shallow, mount } from 'enzyme'
import Itinerary from '../src/components/Application/Itinerary/Itinerary'

const startProperties = {
    'options': {
        'units': {'miles': 3959, 'kilometers': 6371},
        'activeUnit': 'miles',
        'serverPort': 'black-bottle.cs.colostate.edu:31400'
    },
    'itinerary': {
        'requestType'    : 'itinerary',
        'requestVersion' : 3,
        'options'        : {

        },
        'places'         : [],
        'distances'      : []
    },
    'serverConfig':{
        "requestType"        : "config",
        "requestVersion"     : 3,
        "serverName"         : "t02 ",
        "placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "altitude"],
        "optimizations"      : ["none","short"]
    }


};

function testChildExistsRender() {
    const testItinerary = shallow(<Itinerary settings={startProperties.options}
                                             serverConfig={startProperties.serverConfig}
                                             updateResponse={startProperties.itinerary.requestType}
                                             itinerary={startProperties.itinerary}
        />);

    expect(testItinerary.find("Find").length).toEqual(0);
}
test('Testing to see if everything renders correctly with Itinerary', testChildExistsRender);

function testContainerRenderItinerary(){
    const testItinerary = shallow(<Itinerary settings={startProperties.options}
                                             serverConfig={startProperties.serverConfig}
                                             updateResponse={startProperties.itinerary.requestType}
                                             itinerary={startProperties.itinerary}
    />);
    expect(testItinerary.find("Container").length).toEqual(1);
}
test('Test to ensure container renders', testContainerRenderItinerary);

function testMapRenderItin(){
    const testItinerary = shallow(<Itinerary settings={startProperties.options}
                                             serverConfig={startProperties.serverConfig}
                                             updateResponse={startProperties.itinerary.requestType}
                                             itinerary={startProperties.itinerary}
    />);
    expect(testItinerary.find("MapMarker").length).toEqual(1);
}
test('Test to ensure Map renders', testMapRenderItin);

function testCustomePlaceRender(){
    const testItinerary = shallow(<Itinerary settings={startProperties.options}
                                             serverConfig={startProperties.serverConfig}
                                             updateResponse={startProperties.itinerary.requestType}
                                             itinerary={startProperties.itinerary}
    />);
    expect(testItinerary.find("CustomePlace").length).toEqual(0);
}
test('Test to ensure CustomePlace renders', testCustomePlaceRender);

function testPaneRender(){
    const testItinerary = shallow(<Itinerary settings={startProperties.options}
                                             serverConfig={startProperties.serverConfig}
                                             updateResponse={startProperties.itinerary.requestType}
                                             itinerary={startProperties.itinerary}
    />);
    expect(testItinerary.find("Pane").length).toEqual(2);
}
test('Test to ensure Pane renders', testPaneRender);


function testMarker(){
    const testItinerary = shallow(<Itinerary settings={startProperties.options}
                                             serverConfig={startProperties.serverConfig}
                                             updateResponse={startProperties.itinerary.requestType}
                                             itinerary={startProperties.itinerary}
    />);
    expect(testItinerary.find("Marker").length).toEqual(0);
}
test('Test to ensure Markers dont intitially render', testMarker);

function testDownloadRender(){
    const testItinerary = shallow(<Itinerary settings={startProperties.options}
                                             serverConfig={startProperties.serverConfig}
                                             updateResponse={startProperties.itinerary.requestType}
                                             itinerary={startProperties.itinerary}
    />);
    expect(testItinerary.find("Download").length).toEqual(0);
}
test('Test to render test download', testDownloadRender);

function testButtonsRender(){
    const testItinerary = shallow(<Itinerary settings={startProperties.options}
                                             serverConfig={startProperties.serverConfig}
                                             updateResponse={startProperties.itinerary.requestType}
                                             itinerary={startProperties.itinerary}
    />);
    expect(testItinerary.find("Latitude").length).toEqual(0);
}
test('Test to check buttons render', testButtonsRender);

function testPopUps(){
    const testItinerary = shallow(<Itinerary settings={startProperties.options}
                                             serverConfig={startProperties.serverConfig}
                                             updateResponse={startProperties.itinerary.requestType}
                                             itinerary={startProperties.itinerary}
    />);
    expect(testItinerary.find("Popup").length).toEqual(0);
}
test('Test to check popups', testPopUps);