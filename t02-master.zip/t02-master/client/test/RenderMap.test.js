import './enzyme.config.js';
import React from 'react';
import {shallow, mount} from 'enzyme';

import RenderMap from '../src/components/Application/Calculator/RenderMap';
import {Col} from "reactstrap";
import L from "leaflet";
import {CreateOneMarker} from "../src/components/Application/Itinerary/TableItinerary";
import MapMarker from '../src/components/Application/Itinerary/MapMarker'
const startProperties = {

    'origin':{latitude:3,longitude:'4'},
    'destination':{latitude:'3',longitude:'4'}

};

const startProperties2 = {

    'origin':{latitude:'',longitude:''},
    'destination':{latitude:'',longitude:''}

};

function testRenderMap() {
    const renderMap = shallow((
        <RenderMap origin={startProperties.origin}
                   destination={startProperties.destination}
        />

    ));

    let stuff=[];
    let markers=[];

    stuff.push(new L.latLng(startProperties.origin.latitude, startProperties.origin.longitude));
    let tempMarker=CreateOneMarker(startProperties.origin,"Origin");
    markers.push(tempMarker)

    stuff.push(new L.latLng(startProperties.destination.latitude, startProperties.destination.longitude));
    tempMarker=CreateOneMarker(startProperties.destination,"Destination");
    markers.push(tempMarker)

    expect(renderMap.contains((<MapMarker
        itinerary={[]}
        markers = {[]}
        disl={stuff}
        dism={markers}
    />))).toEqual(true);

}


test('Testing RenderMap', testRenderMap);

function testRenderMap2(){
    const renderMap = shallow((
        <RenderMap origin={startProperties2.origin}
                   destination={startProperties2.destination}
        />

    ));
    let stuff=[];
    let markers=[];

    expect(renderMap.contains((<MapMarker
        itinerary={[]}
        markers = {[]}
        disl={stuff}
        dism={markers}
    />))).toEqual(true);

}

test('Testing RenderMap2', testRenderMap2);

test('Testing RenderMap', testRenderMap);

function testRenderMap3(){
    const renderMap = shallow((
        <RenderMap origin={startProperties2.origin}
                   destination={startProperties2.destination}
        />

    ));
    let stuff=[];
    let markers=[];

    expect(renderMap.find("Container").length).toEqual(1);

}

test('Testing RenderMap3', testRenderMap3);

function testRenderMap4(){
    const renderMap = shallow((
        <RenderMap origin={startProperties2.origin}
                   destination={startProperties2.destination}
        />

    ));
    let stuff=[];
    let markers=[];

    expect(renderMap.find("MapMarker").length).toEqual(0);

}

test('Testing RenderMap3', testRenderMap3);