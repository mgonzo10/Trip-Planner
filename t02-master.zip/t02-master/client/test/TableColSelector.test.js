import './enzyme.config.js'
import React from 'react'
import { shallow, mount } from 'enzyme'
import TableColSelector from '../src/components/Application/Itinerary/TableColSelector'

const startProperties = {
    'options': {
        'units': {'miles': 3959, 'kilometers': 6371},
        'activeUnit': 'miles',
        'serverPort': 'black-bottle.cs.colostate.edu:31400'
    },
    'itinerary': {
        'requestType'    : 'itinerary',
        'requestVersion' : 3,
        'options'        : {

        },
        'places'         : [],
        'distances'      : []
    },
    'serverConfig':{
        "requestType"        : "config",
        "requestVersion"     : 3,
        "serverName"         : "t02 ",
        "placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "altitude"],
        "optimizations"      : ["none","short"]
    }


};

function testSelector() {
    let con =  ["leg distance", "cumulative distance"];
    let t = jest.fn();

    const testSelector = shallow(<TableColSelector
            getTableInfo = {t}
            serverConfig={startProperties.serverConfig}
            initialselected={con}
        />);

    expect(testSelector.find("Map").length).toEqual(0);
}
test('Testing to see if everything renders correctly with Itinerary', testSelector);

