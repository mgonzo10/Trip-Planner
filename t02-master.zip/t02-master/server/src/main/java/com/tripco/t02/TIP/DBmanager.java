package com.tripco.t02.TIP;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class DBmanager {

    private static final transient Logger log = LoggerFactory.getLogger(TIPConfig.class);
/*
SET @phrase="%denver%";
SET @phrase="%london%";
SET @phrase="%alf%";
# search query, more columns for  plan query
SELECT world.name, world.municipality, region.name, country.name, continent.name
FROM continent
INNER JOIN country ON continent.id = country.continent
INNER JOIN region ON country.id = region.iso_country
INNER JOIN world ON region.id = world.iso_region
WHERE country.name LIKE @phrase
OR region.name LIKE @phrase
OR world.name LIKE @phrase
OR world.municipality LIKE @phrase
ORDER BY continent.name, country.name, region.name, world.municipality, world.name ASC
LIMIT 10;   */
//id,name,municipality,type,latitude,longitude from colorado
// ("name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude"
//  ["name", "latitude", "longitude", "id", "municipality", "altitude"],
    public static String generateSqlQueryTemplate(String match, int limit, ArrayList<Filter> filters, int SqlType) {



        if(filters==null)
        {
            filters = new ArrayList<Filter>();
        }
          String newsql = new String();

// "Give me all airports from world... where
                // the name matches match or the municipality matches match or... and also the filter-type matches any of the filter-values."

        // return String.format("SELECT * FROM airports WHERE (id LIKE '%%%1$s%%' or type like '%%%1$s%%'"
           //         + " or name like '%%%1$s%%' or municipality like '%%%1$s%%')"
           ///         + " and (airports." + name + " = " + testStr + ")"
           //         + "LIMIT %2$d;", match, limit);
         switch (SqlType){
                case 0:
                    newsql = "SELECT COUNT(*)";
                    break;
                case 1:
                    newsql = "SELECT world.type as type, world.name as name, world.id as id," +
                            "  world.municipality as municipality,world.latitude as latitude,world.longitude as " +
                            "  longitude, world.altitude as altitude, continent.name as continent, region.name as region, country.name as country";
                    break;
            }


            newsql+=(" FROM continent" +
                    "            INNER JOIN country ON continent.id = country.continent " +
                    "            INNER JOIN region ON country.id = region.iso_country " +
                    "            INNER JOIN world ON region.id = world.iso_region ");

            newsql= String.format(newsql+"WHERE (world.id LIKE '%%%1$s%%' or world.type like '%%%1$s%%'"
                + " or world.name like '%%%1$s%%' or world.municipality like '%%%1$s%%')",match);


            for(Filter f : filters)
            { String name_t = f.name;
                ArrayList<String> values_t = f.values;

                if(values_t.size()==0)
                    continue;


                newsql+=("AND ( ");

                for(String s :values_t)
                {

                    String t= String.format(" %1$s LIKE '%%%2$s%%' ",name_t,s);
                    newsql+=t;

                    if(f.values.indexOf(s)!=f.values.size()-1)
                    {
                        newsql+=" or ";

                    }


                }
                newsql+=" ) ";


            }

            if(SqlType==0)
            {
                return newsql;
            }


            String tt= String.format(" ORDER BY continent, country, region, municipality, name ASC " +
                    " LIMIT %1$d;",limit);
            newsql+=tt;

            return newsql;
    }




    public static String generateSqlQuery(String match, int limit,ArrayList<Filter> filters) {


        return generateSqlQueryTemplate(match,limit,filters, 1);
    }

    public static String generateSqlQueryCount(String match, int limit,ArrayList<Filter> filters) {

        return generateSqlQueryTemplate(match,limit,filters, 0);
    }


    /**
     * this.placeAttributes = Arrays.asList("name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude"
     * @param match the destination being searched for.
     * @param limit max number of returned vals.
     * @return count number, and ArrayList of places.
     */
    public static  Map<Integer, ArrayList<Place> > doSqlQuery(String match, Integer limit,  ArrayList<Filter> filters) {

        Map<Integer, ArrayList<Place> > result = new HashMap<Integer, ArrayList<Place>>();
       // Integer tempLimit;
        String myUrl;
        String Regusername;
        String Regpassword;
        ArrayList<Place> searchResults = new ArrayList<Place>();
        int found=0;

        //limit set to max if limit is 0.
        if(limit == null || limit.equals(0))
        {
            limit = Integer.MAX_VALUE;
        }

         String count = generateSqlQueryCount(match,limit,filters);

        String sql = generateSqlQuery(match,limit,filters);
        log.trace(sql);

        String isTravis = System.getenv("TRAVIS");

        if (isTravis != null && isTravis.equals("true"))
        {
            System.out.print("here inside travis");
            //set db url, username and password to travis creds for testing
            Regusername = "travis";
            Regpassword = null;
            myUrl = "jdbc:mysql://localhost/testingDatabase";
        } else {

            //set db url, username and password to CS DB for running
            Regusername = "cs314-db";
            Regpassword = "eiK5liet1uej";
            myUrl = "jdbc:mysql://faure.cs.colostate.edu/cs314";

        }

        try { // connect to the database
            Class.forName("com.mysql.jdbc.Driver");

            Connection conn = DriverManager.getConnection(myUrl, Regusername, Regpassword);

            try { // create a statement

               // Statement st = conn.createStatement();
                Statement stCount = conn.createStatement();
                Statement stQuery = conn.createStatement();

                try { // submit a query
                   // ResultSet rs = st.executeQuery(sql);
                    ResultSet rsCount = stCount.executeQuery(count);
                    ResultSet rsQuery = stQuery.executeQuery(sql);

                    try { // iterate through the query results and print selected columns
                        ///FOUND TO BE ASSIGNED,ITERATE COUNT
                        while (rsQuery.next()) {

                          //  System.out.printf("%s,%s\n", id, name);
// ("name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude"
//  ["name", "latitude", "longitude", "id", "municipality", "altitude"],
                            Place place = new Place();
                            place.id = rsQuery.getString("id");;
                            place.name = rsQuery.getString("name");
                            place.latitude = rsQuery.getString("latitude");
                            place.longitude = rsQuery.getString("longitude");
                            place.municipality = rsQuery.getString("municipality");
                            place.altitude = rsQuery.getString("altitude");

                            place.region = rsQuery.getString("region");
                            place.continent = rsQuery.getString("continent");
                            place.country = rsQuery.getString("country");


                            searchResults.add(place);
                            //System.out.print("hahh****"+place);

                        }

                        rsCount.next();
                         found = rsCount.getInt(1);

                    } finally {
                        rsQuery.close();
                        rsCount.close();
                    }
                } finally {
                    stQuery.close();
                    stCount.close();

                }
            } finally {
                conn.close();
            }
        } catch (Exception e) { // catches all exceptions in the nested try's
        //LOGGER TO BE ADDED
        }
        result.put(found,searchResults);
        return result;
    }



    public static void main(String[] args)
    {
        Filter ne = new Filter();
     //   ArrayList<Filter> filters = new ArrayList<Filter>();
       // ArrayList<Filter> filters = [{"continent",""}];
        ArrayList<String> continentvalue = new ArrayList<String>(Arrays.asList(new String[] {"Africa","Antarctica","Asia","Europe","North America","Oceania"," South America"}));
        ArrayList<String> tt = new ArrayList<String>(Arrays.asList(new String[] {"North America"}));

        ne.name = "type";
        ne.values.add("small_airport");
       ne.values.add("balloonport");
        ne.values.add("heliport");
        //filters.add(ne);
      //filters.add(new Filter("continent",continentvalue));
        //System.out.println("Filters value: " + filters[0].values);
        //filters.add("medium_airport");
  //      generateSqlQuery("Aspen", 3,filters,1);
       // System.out.println(generateSqlQuery("Aspen", 3,filters));
        //System.out.println(generateSqlQueryCount("denver", 100,new Filter("continent",tt)));
        Map<Integer, ArrayList<Place> > result = new HashMap<Integer, ArrayList<Place>>();
        //result = DBmanager.doSqlQuery("denver", 100,  new Filter("continent",tt));
         ArrayList<Place> places=new ArrayList<Place>() ;
         Integer found = new Integer(2);//server side only

        for(Map.Entry<Integer, ArrayList<Place> > entry : result.entrySet())
        {
            found= entry.getKey();
            places = entry.getValue();
        }

        //System.out.println(found);
     //   System.out.println(places.name);

    }
}


