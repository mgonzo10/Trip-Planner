package com.tripco.t02.misc;
import java.lang.Math;


/** Determines the distance between geographic coordinates.
 */

/** Determines the distance between geographic coordinates.
 */


public class GreatCircleDistance {


    public double calcChord(double startLat, double startLong,
                            double destinationLat, double destinationLong) {
        double deltaX = Math.cos(destinationLat) * Math.cos(destinationLong)
                - Math.cos(startLat) * Math.cos(startLong);
        double deltaY = Math.cos(destinationLat) * Math.sin(destinationLong)
                - Math.cos(startLat) * Math.sin(startLong);
        double deltaZ = Math.sin(destinationLat) - Math.sin(startLat);

        double chordLen = Math.sqrt((Math.pow(deltaX, 2) + Math.pow(deltaY, 2) + Math.pow(deltaZ, 2)));

        return chordLen;
    }



    public long calcDist(double startLat, double startLong,
                        double destinationLat, double destinationLong,double earthradius) {
        double startLatRad = Math.toRadians(startLat);
        double endLatRad = Math.toRadians(destinationLat);
        double startLngRad = Math.toRadians(startLong);
        double endLngRad = Math.toRadians(destinationLong);

        double chord = calcChord(startLatRad, startLngRad, endLatRad, endLngRad);

        double legDistance= earthradius * (2 * Math.asin(chord / 2));


        return (long) Math.round(legDistance);

    }
}