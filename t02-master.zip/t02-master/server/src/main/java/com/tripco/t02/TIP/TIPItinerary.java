package com.tripco.t02.TIP;

import com.tripco.t02.misc.GreatCircleDistance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;







public class TIPItinerary extends TIPHeader {

  //'options'        : {},
 // 'places'         : [],
 // 'distances'      : []

  public Option options;
  public ArrayList<Place> places;
  public ArrayList<Long> distances;

    private final transient Logger log = LoggerFactory.getLogger(TIPItinerary.class);




     TIPItinerary() {
    this.requestType = "itinerary";
         this.requestVersion = 3;

     }
 
    TIPItinerary(int version, Option opt, ArrayList<Place> destination) {
    this();
    this.requestVersion = version;
    this.options = opt;
    this.places=destination;
    this.distances = null;
    }


private ArrayList<Long> legDistances() {
    GreatCircleDistance CalDist = new GreatCircleDistance();

    ArrayList<Long> dist = new ArrayList<Long>();

    ArrayList<Place> data = new ArrayList<Place>();
    //data=this.places;

    for(Place p : this.places) {
        data.add(new Place(p));
    }

    Place temp0;
    Place temp1;
    if(data == null) {
     //no places, empty list
      dist.add(new Long(0));
      return dist;
    }

    //dist.add(0);
    data.add(places.get(0));


   for(int i = 0; i <= data.size()-2; i++){
      temp0 = data.get(i);
      temp1 = data.get(i+1);


       double startLat = DMStoDecimal(String.valueOf(temp0.latitude),90);
       double startLong = DMStoDecimal(String.valueOf(temp0.longitude),180);
       double destLat = DMStoDecimal(String.valueOf(temp1.latitude), 90);
       double destLong = DMStoDecimal(String.valueOf(temp1.longitude),180);

       double dd = Double.parseDouble(this.options.earthRadius);
      dist.add(CalDist.calcDist(startLat, startLong, destLat, destLong, dd));
    }
    /*temp0 = data.get(data.size()-1);
    temp1 = data.get(0);

    double startLat = DMStoDecimal(String.valueOf(temp0.latitude),90);
    double startLong = DMStoDecimal(String.valueOf(temp0.longitude),180);
    double destLat = DMStoDecimal(String.valueOf(temp1.latitude), 90);
    double destLong = DMStoDecimal(String.valueOf(temp1.longitude),180);
      double startLat =  Double.parseDouble(temp0.latitude);
    double startLong = Double.parseDouble(temp0.longitude);
    double destLat = Double.parseDouble(temp1.latitude);
    double destLong = Double.parseDouble(temp1.longitude);

    dist.add(CalDist.calcDist(startLat, startLong, destLat, destLong, Double.parseDouble(options.earthRadius)));*/

 return dist;

  }
 
 public double DMStoDecimal(String inputuser, int bound){
    boolean SouthorWest = inputuser.contains("W") | inputuser.contains("w") | inputuser.contains("S") | inputuser.contains("s");
    String input = inputuser.replaceAll("[^-\\d.]", " ");

    int directionSign = SouthorWest ? -1 : 1; //-1 if west or south, 1 otherwise.
    double decimal = 0.0;
    String[] DMSinput = input.split("\\s+");//Lat values should be in range[-90,90] or [90S,90N]
                        //  Long values should be in range [-180, 180] or [180W,180E]
    try{
            if(DMSinput.length==0)
            {
                log.error("there is only white space in the replaced input, so the original {} is invalid input", input);
                //further handling neeeded
            }
          else if(DMSinput.length == 1){
            decimal = directionSign * Double.parseDouble(DMSinput[0]);
              if(!(-1*bound<=decimal && decimal<=bound) )
              {
                  log.error("out of bounds, so the original {} is invalid input", input);
                  return 0;

                  //further handling neeeded

              }
          }
          else if(DMSinput.length == 2){
            double degree = Double.parseDouble(DMSinput[0]);
            double min = Double.parseDouble(DMSinput[1]);
            double sign = Math.signum(degree);

            decimal = sign * directionSign * (Math.abs(degree) + Math.abs(min/60));
              if(!(-1*bound<=decimal && decimal<=bound) )
              {

                  log.error("out of bounds, so the original {} is invalid input", input);
                  //further handling neeeded
                  return 0;


              }
          }
          else if(DMSinput.length == 3) {

            double degree = Double.parseDouble(DMSinput[0]);
            double min = Double.parseDouble(DMSinput[1]);
            double sec = Double.parseDouble(DMSinput[2]);
            double sign = Math.signum(degree);
            //min = (Math.abs(min) + Math.abs(sec/60));
            decimal = sign * directionSign * (Math.abs(degree) + Math.abs(min/60)+Math.abs(sec/3600));
              if(!(-1*bound<=decimal && decimal<=bound) )
              {
                  log.error("out of bounds , so the original {} is invalid input", input);
                  //further handling neeeded
                  return 0;


              }
          }
    }
    catch (Exception e){
      log.error("Exception inside the DMStoDecimal: {}", e);
      decimal = 0.0;
    }
    return decimal;
  }
  
 
 
   public String toString() {
    StringBuilder result = new StringBuilder();
    String NL = System.getProperty("line.separator");

    result.append(this.getClass().getName() + " Object {" + NL);
    result.append(" Option : " + options + NL);
    result.append("  ArrayList<Place> destination: " + places + NL);
    result.append(" distances between calculated: " + distances + NL);
    result.append("}");

    return result.toString();
  }



    public void buildResponse() {


        if(this.options.optimization.equals("none")||this.options.optimization==null)
            this.distances = legDistances();
        else
        {

                Optimizer optimizer = new Optimizer(this);
                optimizer.doOptimization();
                this.places = optimizer.newPlaces;
                this.distances = optimizer.newDist;

        }

        log.trace("buildResponse inside itinerary -> {}", this.toString());
    }

    public ArrayList<Long> getLegDistances() {
        return distances;
    }


 
 
 
  
  
}






