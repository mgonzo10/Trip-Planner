package com.tripco.t02.TIP;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** This class defines the Config response that provides the client
 * with server specific configuration information.
 *  
 * When used with restful API services,
 * An object is created from the request JSON by the MicroServer using GSON.
 * The buildResponse method is called to set the configuration information.
 * The MicroServer constructs the response JSON from the object using GSON.
 *  
 * When used for testing purposes,
 * An object is created using the constructor below.
 * The buildResponse method is called to set the configuration information.
 * The getDistance method is called to obtain the distance value for comparisons.
 */
//{
  //"requestType"        : "config",
  //"requestVersion"     : 3,
  //"serverName"         : "t## name",
  //"placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "altitude"],
  //"optimizations"      : ["none","short"]
//}
  /*
  {
  "requestType"        : "config",
  "requestVersion"     : 3,
  "serverName"         : "t## name",
  "placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "altitude"],
  "optimizations"      : ["none","short"]
}

{
  "requestType"        : "config",
  "requestVersion"     : 4,
  "serverName"         : "t## name",
  "placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude"],
  "optimizations"      : ["none", "short", "shorter"],
  "filters"            : [{"name": "type",
                          "values": ["airport","heliport","balloonport","closed"]}
                         ]
}
+---------------+
| Africa        |
| Antarctica    |
| Asia          |
| Europe        |
| North America |
| Oceania       |
| South America
ArrayList<String> value = new ArrayList<String>(Arrays.asList(new String[] {"airport","heliport","balloonport","closed"}));

//
   */
public class TIPConfig extends TIPHeader {
  private String serverName;
  private List<String> placeAttributes;
  private final transient Logger log = LoggerFactory.getLogger(TIPConfig.class);
  private  List<String>  optimizations;
  private  ArrayList<Filter>  filters;


  public TIPConfig() {
    this.requestType = "config";
  }


  @Override
  public void buildResponse() {
    this.requestVersion=4;
    this.serverName = "t02 the twotwos";
    //["name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude"],
    this.placeAttributes = Arrays.asList("name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude");
    this.optimizations = Arrays.asList("none", "short", "shorter");
    ArrayList<String> value = new ArrayList<String>(Arrays.asList(new String[] {"airport","heliport","balloonport","closed"}));
    //ArrayList<String> continentvalue = new ArrayList<String>(Arrays.asList(new String[] {"Africa","Antarctica","Asia","Europe","North America","Oceania"," South America"}));

    this.filters = new ArrayList<Filter>();
    this.filters.add(new Filter("type",value));
    //this.filters.add(new Filter("continent",continentvalue));


    log.trace("buildResponse -> {}", this.toString());
  }


  String getServerName() {
    return this.serverName;
  }


  List<String> getPlaceAttributes() {
    return this.placeAttributes;
  }

  @Override
  public String toString() {
    return "\nServerName: " + serverName + "\nPlaceAttributes: " + getPlaceAttributes() + "\nRequestType: " + requestType +
            "\nRequestVersion: " + requestVersion;
  }
}
