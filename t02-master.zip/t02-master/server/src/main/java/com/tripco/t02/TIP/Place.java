package com.tripco.t02.TIP;

import com.tripco.t02.misc.GreatCircleDistance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
//["name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude"],
//  //"placeAttributes"    : ["name", "latitude", "longitude", "id", "municipality", "altitude"],
//    this.placeAttributes = Arrays.asList("name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude");

public class Place{

  public String name;
  public String latitude;
  public String longitude;
  public String id;
  public String municipality;
  public String region;
  public String country;
  public String continent;
  public String altitude;



  Place(){};
  Place(String i,String n,String lat, String lon, String m,String al)
  {
    this.id=i;
    this.name=n;
    this.latitude=lat;
    this.longitude = lon;
    this.municipality=m;
    this.altitude = al;
    
  }
  
  
  Place(String i,String n,String lat, String lon, String m,String al, String conti,String coun, String re)
  {
    this.id=i;
    this.name=n;
    this.latitude=lat;
    this.longitude = lon;
    this.municipality=m;
    this.altitude = al;
    this.region=re;
    this.continent=conti;
    this.country = coun;
    
  }
  
  
  
  Place(Place p)
  {
    this.id=p.id;
    this.name=p.name;
    this.latitude=p.latitude;
    this.longitude = p.longitude;
    this.municipality=p.municipality;
    this.country = p.country;
    this.region = p.region;
    this.altitude = p.altitude;
    this.continent = p.continent;

  }

  
}
