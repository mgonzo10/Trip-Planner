package com.tripco.t02.TIP;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;



/**{

 {
 "requestType"    : "find",
 "requestVersion" : 4,
 "match"          : "",
 "narrow"         : [],
 "limit"          : 0,
 "found"          : 0,
 "places"         : []
 }
 * The limit element is optional in the client request and should
 * only appear in the server response if it was provided in
 * the client request. The places and found elements are
 * only required in the server response.
 */
public class TIPFind extends TIPHeader
{
    public String match;
    public ArrayList<Filter> narrow;
    public ArrayList<Place> places;
    public Integer limit ;// optional!!!
    public Integer found ;//server side only


    public TIPFind()
    {
        super();
        this.requestType = "find";
    }

    public String getType(){
        return this.requestType;
    }



    public void buildResponse()

    {

        Map<Integer, ArrayList<Place> > result = new HashMap<Integer, ArrayList<Place>>();
        result = DBmanager.doSqlQuery(match, limit, narrow);
        for(Map.Entry<Integer, ArrayList<Place> > entry : result.entrySet())
        {
            this.found= entry.getKey();
            this.places = entry.getValue();
        }


    }
 } 
