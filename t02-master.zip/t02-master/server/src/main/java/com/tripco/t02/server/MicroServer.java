package com.tripco.t02.server;

import com.google.gson.Gson;

import com.tripco.t02.TIP.TIPConfig;
import com.tripco.t02.TIP.TIPDistance;
import com.tripco.t02.TIP.TIPHeader;
import com.tripco.t02.TIP.TIPItinerary;
import com.tripco.t02.TIP.TIPFind;

import org.everit.json.schema.SchemaException;
import org.everit.json.schema.loader.SchemaLoader;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import java.lang.reflect.Type;

import com.tripco.t02.TIP.TIPItinerary;
import spark.Request;
import spark.Response;
import spark.Spark;
import static spark.Spark.secure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/** A micro server for a single page web application that serves the static files
 * and processes restful API requests.
 */
class MicroServer {

  private final Logger log = LoggerFactory.getLogger(MicroServer.class);


  MicroServer(int serverPort) {
    configureServer(serverPort);
    serveStaticPages();
    processRestfulAPIrequests();
    log.info("MicroServer running on port: {}", serverPort);
  }


  private void configureServer(int serverPort) {
    Spark.port(serverPort);
    String keystoreFile = System.getenv("KEYSTORE_FILE");
    String keystorePassword = System.getenv("KEYSTORE_PASSWORD");
    if (keystoreFile != null && keystorePassword != null) {
      secure(keystoreFile, keystorePassword, null, null);
      log.info("Keystore file: {}", keystoreFile);
      log.info("Keystore password: {}", keystorePassword);
      log.info("MicroServer using HTTPS.");
    }
    else {
      log.info("MicroServer using HTTP.");
    }
    log.trace("Server configuration complete");
  }


  private void serveStaticPages() {
    String path = "/public/";
    Spark.staticFileLocation(path);
    Spark.get("/", (req, res) -> { res.redirect("index.html"); return null; });
    log.trace("Static file configuration complete");
  }


  private void processRestfulAPIrequests() {
    System.out.print("inside processRestfulAPIrequests");

    Spark.get("/api/config", this::processTIPconfigRequest);
    Spark.post("/api/distance", this::processTIPdistanceRequest);
    Spark.post("/api/itinerary", this::processTIPItineraryRequest);
    Spark.post("/api/find", this::processTIPFindRequest);

    Spark.get("/api/echo", this::echoHTTPrequest);
    log.trace("Restful configuration complete");
  }


  private String processTIPconfigRequest(Request request, Response response) {
    log.info("TIP Config request: {}", HTTPrequestToJson(request));
    response.type("application/json");
    response.header("Access-Control-Allow-Origin", "*");
    response.status(200);
    try {
      Gson jsonConverter = new Gson();
      TIPConfig tipRequest = new TIPConfig();
      tipRequest.buildResponse();
      String responseBody = jsonConverter.toJson(tipRequest);
      log.trace("TIP Config response: {}", responseBody);
      return responseBody;
    } catch (Exception e) {
      log.error("Exception: {}", e);
      response.status(500);
      return request.body();
    }
  }


  private String processTIPdistanceRequest(Request request, Response response) {
    return processTIPrequest(TIPDistance.class, request, response);
  }

  private String processTIPItineraryRequest(Request request, Response response) {
    //log.info("check 3", request);
    return processTIPrequest(TIPItinerary.class, request, response);
  }


  private String processTIPFindRequest(Request request, Response response) {
    System.out.print("inside processTIPFindRequest");
    return processTIPrequest(TIPFind.class, request, response);
  }


  private String processTIPrequest(Type tipType, Request request, Response response) {
    log.info("TIP Request: {}", HTTPrequestToJson(request));
    response.type("application/json");
    response.header("Access-Control-Allow-Origin", "*");
    response.status(200);
    String schemaFilePath = null;
    if(tipType.equals(TIPDistance.class)){
      schemaFilePath = "/TIPDistanceSchema.json";
    }
    else if(tipType.equals(TIPItinerary.class)){
      schemaFilePath = "/TIPItinerarySchema.json";
    }
    else if(tipType.equals(TIPFind.class)){
      schemaFilePath = "/TIPFindSchema.json";
    }
    else if(tipType.equals(TIPConfig.class)){
      schemaFilePath = "/TIPConfigSchema.json";
    }
    try {
      boolean validate = validateRequest(request.body(), schemaFilePath);
      if(validate == false){
        System.out.println("here inside schema!!!!! failed");

        response.status(400);
        return request.body();
      }
      Gson jsonConverter = new Gson();
      TIPHeader tipRequest = jsonConverter.fromJson(request.body(), tipType);
      //log.info(request.body());
      tipRequest.buildResponse();

      String responseBody = jsonConverter.toJson(tipRequest);

      log.trace("TIP Response: {}", responseBody);

      return responseBody;
    } catch (Exception e) {
      log.error("Exception: {}", e);
      response.status(500);
      return request.body();
    }
  }

  private boolean validateRequest(String jsonString, String schemaPath){
    JSONObject schemaString = parseJsonFile(schemaPath);
    JSONObject jsonOBJ = new JSONObject(jsonString);
    boolean validationResult = true;
    try {
      if(schemaPath == null){
        return true;
      }
      Schema schema = SchemaLoader.load(schemaString);

      // This is the line that will throw a ValidationException if anything doesn't conform to the schema!
      schema.validate(jsonOBJ);
    }
    catch (SchemaException e) {
      log.error("Caught a schema exception!");
      e.printStackTrace();
      validationResult = false;
    }
    catch (ValidationException e) {
      log.error("Caught validation exception when validating schema! Root message: {}", e.getErrorMessage());
      log.error("All messages from errors (including nested):");
      // For now, messages are probably just good for debugging, to see why something failed
      List<String> allMessages = e.getAllMessages();
      for (String message : allMessages) {
        log.error(message);
      }
      validationResult = false;
    }
    finally {
      return validationResult;
    }
  }

  private JSONObject parseJsonFile(String path) {
    // Here, we simply dump the contents of a file into a String (and then an object);
    // there are other ways of creating a JSONObject, like from an InputStream...
    // (https://github.com/everit-org/json-schema#quickstart)
    JSONObject rawSchema = null;
    try (InputStream inputStream = getClass().getResourceAsStream(path)){
      rawSchema = new JSONObject(new JSONTokener(inputStream));
    }
    catch (IOException e) {
      log.error("Caught exception when reading files!");
      e.printStackTrace();
    }
    catch (JSONException e) {
      log.error("Caught exception when constructing JSON objects!");
      e.printStackTrace();
    }
    finally {
      return rawSchema;
    }
  }

  private String echoHTTPrequest(Request request, Response response) {
    response.type("application/json");
    response.header("Access-Control-Allow-Origin", "*");
    return HTTPrequestToJson(request);
  }


  private String HTTPrequestToJson(Request request) {
    return "{\n"
            + "\"attributes\":\"" + request.attributes() + "\",\n"
            + "\"body\":\"" + request.body() + "\",\n"
            + "\"contentLength\":\"" + request.contentLength() + "\",\n"
            + "\"contentType\":\"" + request.contentType() + "\",\n"
            + "\"contextPath\":\"" + request.contextPath() + "\",\n"
            + "\"cookies\":\"" + request.cookies() + "\",\n"
            + "\"headers\":\"" + request.headers() + "\",\n"
            + "\"host\":\"" + request.host() + "\",\n"
            + "\"ip\":\"" + request.ip() + "\",\n"
            + "\"params\":\"" + request.params() + "\",\n"
            + "\"pathInfo\":\"" + request.pathInfo() + "\",\n"
            + "\"serverPort\":\"" + request.port() + "\",\n"
            + "\"protocol\":\"" + request.protocol() + "\",\n"
            + "\"queryParams\":\"" + request.queryParams() + "\",\n"
            + "\"requestMethod\":\"" + request.requestMethod() + "\",\n"
            + "\"scheme\":\"" + request.scheme() + "\",\n"
            + "\"servletPath\":\"" + request.servletPath() + "\",\n"
            + "\"session\":\"" + request.session() + "\",\n"
            + "\"uri()\":\"" + request.uri() + "\",\n"
            + "\"url()\":\"" + request.url() + "\",\n"
            + "\"userAgent\":\"" + request.userAgent() + "\"\n"
            + "}";
  }


}