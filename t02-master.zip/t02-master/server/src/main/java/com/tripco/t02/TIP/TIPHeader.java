package com.tripco.t02.TIP;

public abstract class TIPHeader {
  protected Integer requestVersion;
  protected String requestType;

  @Override
  public String toString() {

    return "\n Request Version: " + requestVersion + "\n Request Type: " + requestType;
  }

  public abstract void buildResponse();

}
