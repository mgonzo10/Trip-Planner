package com.tripco.t02.TIP;

import com.tripco.t02.misc.GreatCircleDistance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;


// a field of TIPItinerary class
//'options'        : { 'title':'My Trip', 
//'earthRadius':'3958.761316' },

public class Option {

  public String title;
  public String earthRadius;
  public String optimization;

  Option(){};
  Option(String t, String r, String opt)
  {
    this.title = t;
    this.earthRadius =r;
    this.optimization=opt;
  }
}
