package com.tripco.t02.TIP;


        import com.tripco.t02.misc.GreatCircleDistance;
        import java.util.*;




public class Optimizer {
    private TIPItinerary trip;
    public long[][] nnTable;
    private  int[] tour;
    public ArrayList<Place> workingArray;

    public int placesNum ;
    //Test if contain shortest distance. Will become finArray/finDist if they do
    public ArrayList<Place> newPlaces;
    public ArrayList<Long> newDist;
    GreatCircleDistance CalDist = new GreatCircleDistance();



    public Optimizer(TIPItinerary t){

        newPlaces = new ArrayList<>();
        newDist = new ArrayList<>();
        trip = t;
        workingArray = t.places;
        placesNum = t.places.size();

        tour = new int[placesNum+1];

        nnTable = new long[placesNum][placesNum];

        //Populate Table of matrix distance
        for (int i=0; i < placesNum; i++){
            for (int j=0; j < placesNum; j++){
                long dist = MatrixBuilder(workingArray.get(i), workingArray.get(j));
                nnTable[i][j] = dist;
            }
        }
    }


    public boolean allTrue(boolean[] array){
        for(boolean b: array) if(!b) return false;
        return true;
    }

    private long MatrixBuilder(Place place0, Place place1){
        if(place0.latitude == null || place1.latitude == null){
            return 0;
        }
        double dd = Double.parseDouble(this.trip.options.earthRadius);

        double p0lat = Double.parseDouble(place0.latitude);
        double p0long = Double.parseDouble(place0.longitude);
        double p1lat = Double.parseDouble(place1.latitude);
        double p1long =Double.parseDouble(place1.longitude);
        return CalDist.calcDist(p0lat,p0long,p1lat,p1long,dd);
    }

    public int[] Short() { //nearest-neighbor algorithm
        //the first place never change

        boolean [] visited = new boolean[placesNum];

        long finalDist=100000000;
        long tempDist=0;


        int [] tourtemp = new int[placesNum+1];
        int [] finaltour = new int[placesNum+1];


        int last=0;


        for(int i=0;i<placesNum;i++){
            for(int j=0;j<visited.length;j++)
            {
                visited[j]=false;
            }
            visited[i]=true;

            tourtemp[0] = i;
            last=i;
            // visited[i] = true;
            int count=1;
            tempDist=0;

            while(!allTrue(visited))
            {
                int temp = last;

                last = nearest(last,visited);

                tourtemp[count]=last;
                visited[last]=true;
                count++;
                tempDist+=nnTable[temp][last];

            }

            if(tempDist+nnTable[last][i]<finalDist)
            {
                finalDist=tempDist+nnTable[last][i];
                tourtemp[count]=i;
                System.arraycopy( tourtemp, 0, finaltour, 0, tourtemp.length );
            }

        }
        return finaltour;
    }

    void twoOptReverse(int []route, int i1, int k) { // reverse in place
        int temp;
        while(i1 < k) {
            temp = route[i1];
            route[i1] = route[k];
            route[k] = temp;
            i1++;
            k--;
	    }

    }


    void doShorter(int []route){
        boolean improvement = true;
        while(improvement){
            improvement=false;

            for(int i=0;i<=route.length-4;i++){ //We use n-4 rather than n-3 because the TIPIntinerary does not contain the rounded firts one

                for (int k=i+2;k<=route.length-2;k++){ //Same reason
                    int place1=route[i],place2=route[k];
                    int nextPlace1=route[i+1],nextPlace2=route[k+1];
                    long delta=-nnTable[place1][nextPlace1]-nnTable[place2][nextPlace2]+nnTable[place1][place2]+nnTable[nextPlace1][nextPlace2];

                    if(delta<0){
                        twoOptReverse(route,i+1,k);
                        improvement = true;
                        break;
                    }
                }
                if(improvement) break;
            }

        }

        route[route.length-1]=route[0];
    }

    public int[] Shorter() { //2-opt algorithm

        int [] finaltour;

        finaltour=Short();
        doShorter(finaltour);

        return finaltour;
    }

    public void doOptimization()
    {
        if(trip.options.optimization.equals("short"))
        {
            this.tour=Short();
        }
        else if(trip.options.optimization.equals("shorter")){
            this.tour=Shorter();

        }
        this.newDist =this.adjustedDistances();
        this.newPlaces=this. adjustedPlaces();
    }

    public int returnStart(int [] tour)
    {
        int index=-1;
        for(int i=0;i<tour.length-1;i++)//the TIPIntinerary does not contain the rounded firts one
        {
            if(tour[i]==0)
            {
                index=i;
                break;

            }
        }
        return index;

    }

    public  ArrayList<Place>  adjustedPlaces()
    {
        int index = this.returnStart(this.tour);

        ArrayList<Place> newPlaces = new ArrayList<>();
        for(int i=index;i<tour.length-1;i++)//the TIPIntinerary does not contain the rounded firts one
        {

            newPlaces.add(trip.places.get(tour[i]));
        }
        for(int i=0;i<index;i++)//the TIPIntinerary does not contain the rounded firts one
        {

            newPlaces.add(trip.places.get(tour[i]));
        }
        return newPlaces;
    }

    public  ArrayList<Long>   adjustedDistances()
    {
        int index = this.returnStart(this.tour);

        ArrayList<Long> newDist = new ArrayList<>();

        for(int i=index;i<tour.length-1;i++)//the TIPIntinerary does not contain the rounded firts one
        {

            newDist.add(nnTable[tour[i]][tour[i+1]]);
        }
        for(int i=0;i<index;i++)
        {

            newDist.add(nnTable[tour[i]][tour[i+1]]);
        }
        return newDist;
    }

    public int nearest(int current,boolean[] visCities)
    {
        long minDist = (long)Double.POSITIVE_INFINITY;
        int minIndex=0;

        for(int j = 0; j < nnTable[0].length; j++){
            if (nnTable[current][j] < minDist && nnTable[current][j] !=0)
                if(!visCities[j]){
                    minDist = nnTable[current][j];
                    minIndex=j;
                }
        }

        return minIndex;
    }







}