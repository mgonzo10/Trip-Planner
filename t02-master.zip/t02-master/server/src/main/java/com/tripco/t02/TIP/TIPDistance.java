package com.tripco.t02.TIP;

import com.tripco.t02.misc.GreatCircleDistance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;


/** Defines the TIP distance object.
 *
 * For use with restful API services,
 * An object is created from the request JSON by the MicroServer using GSON.
 * The buildResponse method is called to determine the distance.
 * The MicroServer constructs the response JSON from the object using GSON.
 *
 * For unit testing purposes,
 * An object is created using the constructor below with appropriate parameters.
 * The buildResponse method is called to determine the distance.
 * The getDistance method is called to obtain the distance value for comparisons.
 *
 */
public class TIPDistance extends TIPHeader {
  private Map origin;
  private Map destination;
  private Double earthRadius;
  private Long distance;
  private final transient Logger log = LoggerFactory.getLogger(TIPDistance.class);


  TIPDistance(int version, Map origin, Map destination, Double earthRadius) {
    this();
    this.requestVersion = version;
    this.origin = origin;
    this.destination = destination;
    this.earthRadius = earthRadius;
    this.distance =  new Long(0);
  }


  private TIPDistance() {
    this.requestType = "distance";
  }


  public void buildResponse() {
    this.distance =  new Long(0);
    GreatCircleDistance CalDist = new GreatCircleDistance();

    double startLat = DMStoDecimal(String.valueOf(origin.get("latitude")),90);
    double startLong = DMStoDecimal(String.valueOf(origin.get("longitude")),180);
    double destLat = DMStoDecimal(String.valueOf(destination.get("latitude")), 90);
    double destLong = DMStoDecimal(String.valueOf(destination.get("longitude")),180);
    
    if(startLat >=-90 && startLat <= 90 && startLong <= 180 && startLong >= -180 && destLat <= 90 && destLat >= -90 && destLong <= 180 && destLong >= -180){
      distance = CalDist.calcDist(startLat, startLong, destLat, destLong, earthRadius);
      log.trace("buildResponse -> {}", this.toString());
      //System.out.println("not failed");
    }
    //else System.out.println("failed");

  }

  public String toString() {
    StringBuilder result = new StringBuilder();
    String NL = System.getProperty("line.separator");

    result.append(this.getClass().getName() + " Object {" + NL);
    result.append(" requestVersion: " + requestVersion + NL);
    result.append(" origin coordinates: " + origin + NL);
    result.append(" destination coordinates: " + destination + NL);
    result.append(" earthRadius: " + earthRadius + NL);
    //Note that Collections and Maps also override toString
    result.append(" distance calculated: " + distance + NL);
    result.append("}");

    return result.toString();
  }
  
  
  public double DMStoDecimal(String inputuser, int bound){
    boolean SouthorWest = inputuser.contains("W") | inputuser.contains("w") | inputuser.contains("S") | inputuser.contains("s");
    String input = inputuser.replaceAll("[^-\\d.]", " ");

    int directionSign = SouthorWest ? -1 : 1; //-1 if west or south, 1 otherwise.
    double decimal = 0.0;
    String[] DMSinput = input.split("\\s+");//Lat values should be in range[-90,90] or [90S,90N]
                        //  Long values should be in range [-180, 180] or [180W,180E]
    try{
            if(DMSinput.length==0)
            {
                log.error("there is only white space in the replaced input, so the original {} is invalid input", input);
                //further handling neeeded
            }
          else if(DMSinput.length == 1){
            decimal = directionSign * Double.parseDouble(DMSinput[0]);
              if(!(-1*bound<=decimal && decimal<=bound) )
              {
                  log.error("out of bounds, so the original {} is invalid input", input);
                  //further handling neeeded

              }
          }
          else if(DMSinput.length == 2){
            double degree = Double.parseDouble(DMSinput[0]);
            double min = Double.parseDouble(DMSinput[1]);
            double sign = Math.signum(degree);

            decimal = sign * directionSign * (Math.abs(degree) + Math.abs(min/60));
              if(!(-1*bound<=decimal && decimal<=bound) )
              {
                  log.error("out of bounds, so the original {} is invalid input", input);
                  //further handling neeeded

              }
          }
          else if(DMSinput.length == 3) {

            double degree = Double.parseDouble(DMSinput[0]);
            double min = Double.parseDouble(DMSinput[1]);
            double sec = Double.parseDouble(DMSinput[2]);
            double sign = Math.signum(degree);
            //min = (Math.abs(min) + Math.abs(sec/60));
            decimal = sign * directionSign * (Math.abs(degree) + Math.abs(min/60)+Math.abs(sec/3600));
              if(!(-1*bound<=decimal && decimal<=bound) )
              {
                  log.error("out of bounds , so the original {} is invalid input", input);
                  //further handling neeeded

              }
          }
    }
    catch (Exception e){
      log.error("Exception inside the DMStoDecimal: {}", e);
      decimal = 0.0;
    }
    return decimal;
  }
  
  

    long getDistance() {
    return distance;
  }
}
