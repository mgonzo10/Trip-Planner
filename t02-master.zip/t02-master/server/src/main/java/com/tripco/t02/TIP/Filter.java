package com.tripco.t02.TIP;

import java.util.ArrayList;

public class Filter {
    String name;
    ArrayList<String> values;

    Filter(String names, ArrayList<String> val)
    {
        this.name = names;
        this.values=val;
    }

    public Filter() {
        ArrayList<String> value = new ArrayList<String>();
        String attributes = "";
        this.values = value;
        this.name = attributes;
    }

  
}
