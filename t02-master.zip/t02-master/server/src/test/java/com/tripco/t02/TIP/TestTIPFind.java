package com.tripco.t02.TIP;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class TestTIPFind {
    private TIPFind tipfind;

    @Before
    public void createTIPFindForTestCases(){
        tipfind = new TIPFind();
       // tipfind.buildResponse();
    }

    @Test
    public void testType() {
        String type = tipfind.getType();
        assertEquals("TIPfind requestType", "find", type);
    }


}
