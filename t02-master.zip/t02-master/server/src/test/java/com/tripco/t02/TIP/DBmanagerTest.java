package com.tripco.t02.TIP;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.tripco.t02.TIP.DBmanager.generateSqlQuery;
import static com.tripco.t02.TIP.DBmanager.generateSqlQueryCount;

import static org.junit.Assert.*;

public class DBmanagerTest {

    Filter ne = new Filter();
    ArrayList<Filter> filters = null;
    @Before
    public void createFilters(){



        ne.name = "type";
        ne.values.add("small_airport");
        ne.values.add("balloonport");
        ne.values.add("heliport");
       // filters.add(ne);
    }
@Test
    public void testgenerateSqlQueryTemplate()
{
String expected ="SELECT world.type as type, world.name as name, world.id as id,  world.municipality as municipality,world.latitude as latitude,world.longitude as   longitude, world.altitude as altitude, continent.name as continent, region.name as region, country.name as country FROM continent            INNER JOIN country ON continent.id = country.continent             INNER JOIN region ON country.id = region.iso_country             INNER JOIN world ON region.id = world.iso_region WHERE (world.id LIKE '%denver%' or world.type like '%denver%' or world.name like '%denver%' or world.municipality like '%denver%') ORDER BY continent, country, region, municipality, name ASC  LIMIT 100;" ;

    assertEquals( generateSqlQuery("denver", 100,filters), expected);
}

    @Test
    public void testgenerateSqlQueryTemplateCount()
    {
       String actaul =  generateSqlQueryCount("denver", 100,filters);

        String expected ="SELECT COUNT(*) FROM continent            INNER JOIN country ON continent.id = country.continent             INNER JOIN region ON country.id = region.iso_country             INNER JOIN world ON region.id = world.iso_region WHERE (world.id LIKE '%denver%' or world.type like '%denver%' or world.name like '%denver%' or world.municipality like '%denver%')";
        assertEquals( actaul, expected);
    }





}
