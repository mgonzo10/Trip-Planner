package com.tripco.t02.misc;


import java.util.List;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestGreatCircleDistance {

    private GreatCircleDistance gcd;

    @Before
    public void createOptionsAndPlacesForTestCases() {
        gcd=new GreatCircleDistance();



    }

    @Test
    public void testData1() {
        long expected = 345;
        long actual = gcd.calcDist(3, 4, 6, 8, 3959);
        assertEquals("distance", expected, actual);

    }
    @Test
    public void testData2() {
        long expected = 3417;
        long actual = gcd.calcDist(32, 45, 61, -18, 3959);
        assertEquals("distance", expected, actual);

    }

    @Test
    public void testData3() {
        long expected = 7809;
        long actual = gcd.calcDist(-32, -5, 81, -8, 3959);
        assertEquals("distance", expected, actual);

    }

}
