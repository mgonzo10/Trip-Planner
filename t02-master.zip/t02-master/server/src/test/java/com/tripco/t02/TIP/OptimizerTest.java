package com.tripco.t02.TIP;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import java.util.*;


public class OptimizerTest {
    @Test
    public void allTrue() throws Exception {
    }

    @Test
    public void Short() throws Exception {
        int [ ] expected = {0,1,2,0};
        assertArrayEquals(expected,optimizer1.Short());

    }


    @Test
    public void doOptimization() throws Exception {


    }

    @Test
    public void adjustedPlaces() throws Exception {

        optimizer2.doOptimization();
        ArrayList<Place> placesExpected = new ArrayList<>();

        placesExpected.add(new Place("dnvr", "Denver","39.7392", "-104.9903","municipal","al"));
        placesExpected.add(new Place("bldr", "Boulder",       "40.01499", "-105.27055","municipal","al"));
        placesExpected.add(new Place("foco", "Fort Collins", "40.585258",  "-105.084419","municipal","al"));

        ArrayList<String> expected_name = new ArrayList<>();
        expected_name.add("Denver");
        expected_name.add("Boulder");
        expected_name.add("Fort Collins");

        placesExpected = optimizer2.newPlaces;
        ArrayList<String> actul_name = new ArrayList<>();
        actul_name.add(placesExpected.get(0).name);
        actul_name.add(placesExpected.get(1).name);
        actul_name.add(placesExpected.get(2).name);


        assertEquals(expected_name, actul_name);

    }

    @Test
    public void adjustedDistances() throws Exception {
    }

    @Test
    public void nearest() throws Exception {

        boolean [] visted  = new boolean[3];
        int expected = 1;
        assertEquals(expected,optimizer1.nearest(0,visted));

    }

    private Map<String, Object> csu;
    public ArrayList<Place> places1;

    private final int version = 1;
    private Option opt1;
    private Option opt2;

    TIPItinerary trip1;
    TIPItinerary trip2;
    TIPItinerary trip3;

    Optimizer optimizer1;
    Optimizer optimizer2;
    Optimizer optimizer3;


    @Before
    public void initialize() {

        opt1= new Option("My Trip","3958.761316","none" );
        opt2= new Option("My Trip two km","6371.0088" ,"short");

        places1 = new ArrayList<Place>();
        places1.add(new Place("dnvr", "Denver","39.7392", "-104.9903","municipal","al"));
        places1.add(new Place("bldr", "Boulder",       "40.01499", "-105.27055","municipal","al"));
        places1.add(new Place("foco", "Fort Collins", "40.585258",  "-105.084419","municipal","al"));




        trip1 = new TIPItinerary();
        trip1.places = places1;
        trip1.options=opt1;
        optimizer1 = new Optimizer(trip1);
        trip2 = new TIPItinerary();

        trip2.options = opt2;
        trip2.places = places1;
        optimizer2 = new Optimizer(trip2);
        trip3 = new TIPItinerary();



    }






}
