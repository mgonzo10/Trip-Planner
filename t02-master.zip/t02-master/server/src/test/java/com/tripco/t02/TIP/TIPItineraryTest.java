package com.tripco.t02.TIP;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

public class TIPItineraryTest {

    private final long radiusMiles = 3958;
    private Map<String, Object> csu;
    public ArrayList<Place> places1;

    private final int version = 1;
    private Option opt1;
    private Option opt2;

    private TIPItinerary itinerary;
    private TIPItinerary itinerary1;

    @Before
    public void createOptionsAndPlacesForTestCases() {
        itinerary = new TIPItinerary();
        itinerary1 = new TIPItinerary(4 , new Option() , new ArrayList<Place> ());
        opt1= new Option("My Trip","3958.761316","none" );
        opt2= new Option("My Trip two km","6371.0088" ,"none");

        places1 = new ArrayList<Place>();
        places1.add(new Place("dnvr", "Denver","39.7392", "-104.9903","municipal","al"));
        places1.add(new Place("bldr", "Boulder",       "40.01499", "-105.27055","municipal","al"));
        places1.add(new Place("foco", "Fort Collins", "40.585258",  "-105.084419","municipal","al"));

        Place tempPlace= new Place();
        Place tempPlace1=new Place(tempPlace);
        places1.add(tempPlace);
        places1.add(tempPlace1);

    }

    //@Test
/*    public void testThreeLocationIinerary() {
        TIPItinerary itinerary = new TIPItinerary(2, opt1, places1);
        ArrayList<Long> expectDistance = new ArrayList<Long>();
        expectDistance.addAll(Arrays.asList(24l,41l,59l));
        itinerary.buildResponse();
        ArrayList<Long> actual = itinerary.getLegDistances();
        assertEquals("test for only three-location itnerary", expectDistance, actual);
    }*/
    @Test
    public void testDMStostringIinerary() {




//Lat values should be in range[-90,90] or [90S,90N]
        //  Long values should be in range [-180, 180] or [180W,180E]


        //method returns
        assertEquals(itinerary.DMStoDecimal("19.192",180),19.192,0);
        //Letter handling
        assertEquals(itinerary.DMStoDecimal("0° 0' 0\" N",90), 00.000,0);
        assertEquals(itinerary.DMStoDecimal("0° 0' 0\" W",180), 00.000,0);
        assertEquals(itinerary.DMStoDecimal("0° 0' 0\" E",180), 00.000,0);
        assertEquals(itinerary.DMStoDecimal("0° 0' 0\" S",90), 00.000,0);
        //Number inside range
        assertEquals(itinerary.DMStoDecimal("112° 32' 45\" W",180), -112.546,0.001);
        assertEquals(itinerary.DMStoDecimal("40° 41' 41\" N",90), 40.695,0.001);
        assertEquals(itinerary.DMStoDecimal("38° 01.383' N",90), 38.023,0.001);
        assertEquals(itinerary.DMStoDecimal("106.988° W",180), -106.988,0.001);
        assertEquals(-40.001, itinerary.DMStoDecimal("-40.001",180),.001);
        //Numbers outside range
        assertEquals(itinerary.DMStoDecimal("100° 32' 45\" N",90), 0,0.001);
        assertEquals(itinerary.DMStoDecimal("190° 32' 45\" W",90), 0,0.001);


    }

    @Test
    public void testTIPItinerary(){
        assertEquals(itinerary.requestType , "itinerary");
        assertEquals(itinerary.requestVersion , new Integer(3) );
        assertEquals(itinerary1.requestType , "itinerary");
        assertEquals(itinerary1.requestVersion , new Integer(4) );

    }

    @Test
    public void testToString(){
        StringBuilder result = new StringBuilder();
        String NL = System.getProperty("line.separator");

        result.append(itinerary.getClass().getName() + " Object {" + NL);
        result.append(" Option : " + itinerary.options + NL);
        result.append("  ArrayList<Place> destination: " + itinerary.places + NL);
        result.append(" distances between calculated: " + itinerary.distances + NL);
        result.append("}");
        assertEquals(itinerary.toString(),result.toString());


    }

    @Test
    public void testGetLegDistances()  {
        assertEquals(itinerary.getLegDistances(),null);

    }

}
