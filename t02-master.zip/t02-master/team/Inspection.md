# Inspection - Team *T02* 
 
| Inspection | Details |
| ----- | ----- |
| Subject | *Itinerary.js and DBManager.java file ----- Special attention to getFile() and all upload/download methods including sendResponse()* |
| Meeting | *08 April 2019, 1550, CS314 Lecture in the stadium* |
| Checklist | *reference, URL, etc.* |

### Roles

| Name | Preparation Time |
| ---- | ---- |
|Wenrui Ma - Tester | 1hr |
| Wenhao Li - Tester | 1hr |
| Maritza Gonzalez - Maintainer | 1 hr |
| Joel Topps - End User | ~1hr |


### Problems found

| file:line | problem | hi/med/low | who found | github#  |
| --- | --- | :---: | :---: | --- |
| Itinerary.js:498,292  | When uplaoding a file where the lat and long are not decimal(like the fisrt demo file), the table display it to be the converted decimal instead of the original DMS |med | Wenrui Ma| #222|
| DBmanager.java line 39 to end | Search function can't work when searching "Mount Harvard" with "14ers.json"|med | Wenhao| #209|
| Itinerary.js:270 | this method is really long, according to clean code. maybe fine a better way to implement this.  If possible, clean this entire file bc it's kind of messy | low | Maritza | #211 |
| Itinerary.js:all | lots of unnecessary comments, we should go back and clean all of it up | low | Maritza | #211 |
| Itinerary.js line 134 to 150 | Although the option to select the map background was implemented on the home page, it wasn't in the itinerary page | low | Joel | #214 |
| Itinerary.js line 416 to 448| file reader is unable to read the countyseats1.json file "Type error cannot read property '0' of undefined" | high | Joel | #215 |
 
