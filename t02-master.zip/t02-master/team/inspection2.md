# Inspection - Team *T02* 
 
| Inspection | Details |
| ----- | ----- |
| Subject | *Optimizer.java on server side, other Java files* |
| Meeting | *15 April 2019, 1550, CS314 Lecture in the stadium* |
| Checklist | *reference, URL, etc.* |

### Roles

| Name | Preparation Time |
| ---- | ---- |
| Wenrui Ma  | 1hr |
| Wenhao Li - Tester | 1hr |
| Maritza Gonzalez - Maintainer | 1 hr |
| Joel Topps - End User | ~1hr |



### Problems found

| file:line | problem | hi/med/low | who found | github#  |
| --- | --- | :---: | :---: | --- |
| Optimizer.java  | Instead of setting them to be all public, the most appropriate access modifier should be used  |low | Wenrui Ma| #235|
| Optimizer.java:89:319  | Different optimization algorithm can be placed in separate class to make the code clearer  |low | Wenhao Li| #230 |
| Optimizer.java: 208 | In doOptimatization() function, system tells us that the array we return is grey'd out and is "redundant code" | high? | Joel Topps | #232 |
| Optimizer.java | when watching the console when we hit plan with 'shorter' selected. the console seems to show that we're in a loop. doesn't produce more output until running a different class task. | high | Joel Topps | #233 |
| DBmanager.java:all | issues with readability, work on sanitation of varibles, still vulnerable to attacks | med | Maritza | #199 |


### Feedback

#235 and #230 are at low priority for this sprint. We will leave it to the next sprint.
#233 was fixed by commenting a few lines that used for testing.
