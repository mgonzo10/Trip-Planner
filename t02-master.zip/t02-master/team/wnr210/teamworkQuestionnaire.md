# Teamwork Questionnaire for wenrui

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 
   * I don't check my phones a lot, so any way of contacting me involving chell phone may cause late replies. Email is a good option, and 
   since we are using Slack for this course, discussing on the Slack channel might be more efficient.
1. __What are your expectations about what your team will accomplish this semester?__ 
   * Not only do we get A but also we become friends and a good team.
1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 
   * Learn how to express my ideas in a team.
   * Learn how to communicate with my teammates.
   * Learn how to coordinate and distribute the total workload with the whole team 
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 
   * My lack of experiences of working in a team.
   * My introvert personaliy that hinders me from talking in a group.
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 
   * I think the grading system is efficient enough to enable those who deserve an "A" to get an "A". 
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 
   * Yes. 
1. __How much time per week do you anticipate it will take to make the project successful?__ 
   * 1 to 2 hour per day, 7 hours per week.
1. __How will you decide who should do what on the project and activities?__ 
   * We should talk about this within the team.
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 
   * Send a reminder on Slack.
1. __What happens if people have different opinions on the quality of the work?__ 
   * Make a discussion first, if not solved, go to TAs or the professor for help.
1. __How will you deal with different work habits of team members?__ 
   * Different habits won't hurt us as long as we communicate and do our jobs.
1. __Do you want to have a standing meeting time outside of class?__ 
   * Yes!
1. __How often do you think the team will need to meet outside of class?__ 
   * It is doable to have a meeting immediately after class,
1. __Will you need approval of every team member before making a decision?__ 
   * Depends on the issue. If we are deciding the name of our team, every one should agree on the final name we choose.
   However, if it is more individual issue, no such consensus is necessary.
1. __What will you do if every team member except one agrees on something?__ 
   * The whole team should talk about this in order to come up with better solutions. Forcing him/her to compromise is the 
   last choice.
1. __What will you do if one person seems to be dominating the team process?__ 
   * Make a discussion within the team first, try to allocate the work better. If not solved, go to TAs or the professor for help.
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 
   * Make a discussion within the team first, if not solved, go to TAs or the professor for help.
