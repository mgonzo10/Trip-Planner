# Teamwork Questionnaire for jaylizzhn

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 
   * Text is awesome. You can contact me anytime and I would reply ASAP when I see it.
1. __What are your expectations about what your team will accomplish this semester?__ 
   * I expect each my teammate could take this project seriously and work hard on it.
1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 
   * Learn how to do teamwork just like the employees in real world do.
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 
   * I wish my English skill would not be an obstacle.
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 
   * I respect others choice, but I will do the best of my job no matter whether others do.
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 
   * Yes. If you want to share more work for a better grade, why not.
1. __How much time per week do you anticipate it will take to make the project successful?__ 
   * 1 hour per day, 7 hours per week.
1. __How will you decide who should do what on the project and activities?__ 
   * By discussion.
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 
   * Have a talk. I suggest we should notice our pair's progress and remind him/her if his/her part was about to due.
1. __What happens if people have different opinions on the quality of the work?__ 
   * Talk as a team.
1. __How will you deal with different work habits of team members?__ 
   * I respect their habits as long as they finish the job in time.
1. __Do you want to have a standing meeting time outside of class?__ 
   * Yes, I'd love to.
1. __How often do you think the team will need to meet outside of class?__ 
   * Once or twice per week?
1. __Will you need approval of every team member before making a decision?__ 
   * I don't think so, cuz that would be inefficient. As long as we can find another teammate agree with you.
1. __What will you do if every team member except one agrees on something?__ 
   * I have no idea.
1. __What will you do if one person seems to be dominating the team process?__ 
   * Communication is important. I think they are nice guys to work with and I think that is not gonna happen.
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 
   * I will chat with my teammate to reach out a better solution.
