# Teamwork Questionnaire for Joel Topps #

1. **Is it generally easier to reach you by text, electronic mail, voice mail or something else? What hours?**
    - Text, and just about any time of day.
1. **What are your expectations about what your team will accomplish this semester?**
    - I expect each team member to carry their own weight and do it in a timely manner.
1. **What are your personal goals for improving your teamwork and communication skills this semester?**
    - I hope to work on assignments over time and well before the due date to avoid any problems brought on by procrastination.
1. **What kinds of obstacles might you encounter in trying to reach both your team and personal goals?**
    - I have a very busy schedule this semester, so I need to hold myself accountable to get work done on time.
1. **What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?**
    - I believe it is selfish to not do your best as a member of a team. Your teamates are counting on you don't let them down.
1. **Is it acceptable for some team members to do more work on the assignment in order to get an “A”?**
    - I believe that every team member should do as much work as it takes to get the grade the team desires.
1. **How much time per week do you anticipate it will take to make the project successful?**
    - I plan to spend at least 10 hours a week on the project.
1. **How will you decide who should do what on the project and activities?**
    - The distribution should be decided based on who has experience or an interest in that section.
1. **What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?**
    - The team will have a conversation with them, but will also recognize our own failure as we didn't pay attention and notify that person prior.
1. **What happens if people have different opinions on the quality of the work?**
    - We will work out the disputes as a team.
1. **How will you deal with different work habits of team members?**
    - everyone works in their own style, and i will be patient and accepting of everyones style as long as we get work done.
1. **Do you want to have a standing meeting time outside of class?**
    - I believe we will have to meet up as we see fit to complete the project.
1. **How often do you think the team will need to meet outside of class?**
    - As often as necessary dependent on progress in the project.
1. **Will you need approval of every team member before making a decision?**
    - For many decisions we will just need a majority rule.
1. **What will you do if every team member except one agrees on something?**
    - We will use majority rule.
1. **What will you do if one person seems to be dominating the team process?**
    - I will do my best to work things out or stop being such a jerk if i'm the one dominating it.
1. **What will you do if you feel most of the facilitation responsibilities are falling on you?**
    - I will have a talk with my group asking them to step up because I'm feeling burnt out.
