## Teamwork Questionnaire for _Maritza_

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 
   * Anytime before 10 pm by text or email.
1. __What are your expectations about what your team will accomplish this semester?__ 
   * Hopefully we have a really cool website to show at the end!
1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 
   * I like working with other people but I normally am the "idea pitcher", so I look forward to seeing other peoples ideas.
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 
   * I guess I am kind of "bossy", I like things to be done a certain way so I would need to work on accepting others styles and ideas.
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 
   * We can take turns on which ideas to take, to reduce the amount of disagreement.
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 
   * Nope.
1. __How much time per week do you anticipate it will take to make the project successful?__ 
   * at least 8 hours but  we should work no more than 12.
1. __How will you decide who should do what on the project and activities?__ 
   * I love planning and making lists, during each team meeting we should have a bulleted list and make sure we stay on track. 
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 
   * Ideally, we would make them accountable for finishing their work next, have a conversation and if nothing changes time after time, tell Dave.
1. __What happens if people have different opinions on the quality of the work?__ 
   * We would need to compromise and find something everyone is okay with.
1. __How will you deal with different work habits of team members?__ 
   * Teamwork is about trust. If things are done right and on time there should be no problem.
1. __Do you want to have a standing meeting time outside of class?__ 
   * Yes!
1. __How often do you think the team will need to meet outside of class?__ 
   * At least once a week.
1. __Will you need approval of every team member before making a decision?__ 
   * No, use your best judgment.  If there is something questionable then ask but not every decision.
1. __What will you do if every team member except one agrees on something?__ 
   * Do our best to compromise but realize that not everything can go your way, do what's best for the team.
1. __What will you do if one person seems to be dominating the team process?__ 
   * Communication is key for teamwork too, we would have to tell that person that each team member is equal and they would have to trust everyone else.
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 
   * I'm not afraid to ask for help, so first I would ask my team members for help, but the eventually ask for Dave's help.
