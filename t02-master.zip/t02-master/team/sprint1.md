# Sprint 1 - *T02* - *The TwoTwos*

## Goal

### Distance Calculator!
### Sprint Leader: *Joel Topps*

## Definition of Done

* Web application deployed on the production server (black-bottle.cs.colostate.edu).
* Version in server/pom.xml should be `<version>1.0</version>`.
* Product Increment release `v1.0` created on GitHub.
* Sprint Review and Restrospectives completed (team/sprint#.md).

## Policies

* All commits include a task/issue number.
* Someone else approves and merges commits, you may not merge your own changes.
* No commits to master

## Plan

Epics planned for this release.

* *#22 User: I want to compute the distance between two locations on the planet.*
* *#23 User: I want to know where I am on the map*
* *#24 User: I may need distances in other units of measure*
* *#25 TripCo: Use a standard logging system on the server*
* *#26 User: I'd like ot know who to thank for this tool*
* *#27 TripCo: The application should identify the client and server currently in use.*


## Review

#### Completed epics in Sprint Backlog 
* *#22 User: I want to compute the distance between two locations on the planet.*: 
* *#25 TripCo: Use a standard logging system on the server*:  We had some minor difficulties on this because we didn't understand it initially and put it off until Wednesday 2/7/19 until we were able to verify with our  manager (Dave) what was expected. After clarification it was a simple task.
* *#26 User: I'd like ot know who to thank for this tool*: Up and running. Hardest part was creating the actual webpage to add data into.
* *#27 TripCo: The application should identify the client and server currently in use.*: Server name: T02 The TwoTwos 

#### Incomplete epics in Sprint Backlog 
* *#23 User: I want to know where I am on the map*: We ran out of time before the Sprint checkin time arrived. Didn't reach this Epic until Thursday 2/7/19
* *#24 User: I may need distances in other units of measure*: Didn't reach this epic at all. Ran out of time and didn't prioritize compared to other taskings.

#### What went well
* Team client side updates made quickly
* About page made clean and easy to read
* Calculating Distance is accurate and dependable

#### Problems encountered and resolutions
* We need to write test cases for code as we do it. Each task should have two people assigned to it to ensure that the same person who writes initial code isn't the only one testing it.
* We put off Epic #25 until late because we didn't understand it and didn't ask for clarification. Fortunately when we finally asked it was an easier epic. We will fix this by asking questions early and getting ahead of the problem. 
* Accidentally committed to master from github by creating new branches improperly. Each team member did it at least once. Next sprint we will be more careful and ask for a better explanation on creating new branches that are NOT pushing to master.

## Retrospective

#### What went well
* Team Communication
* Team Involvement
* Spaced out workload over time
* Team Cohesion
#### Potential improvements
* Maritza and Ma both were tasked with more time consuming tasks than Lee and Joel. We need to make better estimates of task time/difficulty and more evenly distribute
* Have more meetings to ensure we are all working/on the same page
#### What we will change next time
* Write tests as we code
* Meet all together more than once
* Plan more thoroughly