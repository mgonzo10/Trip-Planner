# Sprint 4 - *t02* - *two twos*

## Goal

### Worldwide!
### Sprint Leader: *Wenhao Li*

## Definition of Done

* Version in pom.xml should be `<version>4.0.0</version>` for your final build for deployment.
* Increment release `v4.0` created on GitHub with appropriate version number and name.
* Increment `server-3.5.jar` deployed for testing and demonstration on CHECK4 assignment.
* Increment `server-4.0.jar` deployed for testing and demonstration on SPRINT4 assignment.
* Sprint Review, Restrospective, and Metrics completed (team/sprint4.md).


## Policies

#### Mobile First Design!
* Design for mobile, tablet, laptop, desktop (in that order).
* Use ReactStrap for a consistent interface (no HTML, CSS, style, etc.).
* Must adhere to the TripCo Interchange Protocol (TIP) for interoperability and testing.
#### Clean Code
* Code Climate maintainability of A or B.
* Code adheres to Google style guides for Java and JavaScript.
#### Test Driven Development
* Write method headers, unit tests, and code in that order.
* Unit tests are fully automated.
* Code Coverage above 50%
#### Configuration Management
* Always check for new changes in master to resolve merge conflicts locally before committing them.
* All changes are built and tested before they are committed.
* All commits include a task/issue number.
* All commits include tests for the added or modified code.
* All tests pass.
#### Continuous Integration / Delivery 
* Master is never broken.  If broken, it is fixed immediately.
* Continuous integration successfully builds and tests all pull requests for master branch.
* All Java dependencies in pom.xml.  Do not load external libraries in your repo. 


## Plan

This sprint will complete the following Epics.

* *#132 User: Give me a friendly message if something goes wrong: Was prioritized last by the team, and wasn't reached in time.*
* *#139 TripCo:Validate all requests sent to the server and responses received by the client: We put this epic in the icebox and prioritized other epics over this. By the time we reached it, we had ran out of time to finish it fo this sprint.*
* *#188 epic User: I would like to highlight certain places on the map*
* *#189 epic User: Let me plan trips world wide.*
* *#190 epic User: I want to view my trip in other tools.*
* *#191 epic User: Can trips be shorter?*

The following is the effect picture we hope to achieve after this sprint finished. 

![Diagrams](https://github.com/csucs314s19/t02/blob/master/team/Images/IMG_20190401_154944.jpg)

The following is the client hierarchy.
![Client](https://github.com/csucs314s19/t02/blob/master/team/Images/clientHierarchy.jpg)

The following is the server hierarchy.
![Server](https://github.com/csucs314s19/t02/blob/master/team/Images/serverHierarchy.jpg)


## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | *6* | *4* |
| Tasks |  *41*   | *39* | 
| Story Points |  *30*  | *28* | 


## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| *4/1* | *#none* | *#168* | *Just started* |
| *4/3* | *#none* | *#168,#198* | *Nope* |
| *4/8* | *#none* | *#168, #198, #142* | *None* |
| *4/12* | *#142, #194, #196, #197, #198, #200, #201, #209, #221, #223* | *#168, #195, #201, #202* | *None* |
| *4/15* | *#201, #233* | *#168, #190, #195, #199, #202, #228* | *None* |
| *4/17* | *#199, #239, #240* | *#168, #195, #202, #228* | *Fix itinerary, fix schemas* |
| *4/18* | *#168, #202* | *#195, #228* | *Fix schemas* |
## Review (focus on solution and technology)

In this sprint, we finished 4 important epics. In these epics, we implemented the 2-opt algorithm, made a banner which will pop up when something goes wrong.
 We made a function to output the data into CSV and KML formats. Above all, we expanded out database working fine worldwidely.

#### Completed epics in Sprint Backlog 

These Epics were completed.

* *#132 User: Give me a friendly message if something goes wrong.*
* *#189 epic User: Let me plan trips world wide.*
* *#190 epic User: I want to view my trip in other tools.*
* *#191 epic User: Can trips be shorter?*

#### Incomplete epics in Sprint Backlog 

These Epics were not completed.

* *#139 TripCo:Validate all requests sent to the server and responses received by the client: Our team member is working on this. This function basically works well, but still needs more tests before we close this epic.*
* *#188 epic User: I would like to highlight certain places on the map: So far, we haven't implement this function. Since this is not the focus of this sprint, we prioritized it low and planed to leave it for the next sprint.*

#### What went well

We finished all main tasks for this sprint a few days before the due date. That's a great progress for cooperation.
As a result, we have more time to add more test functions.

#### Problems encountered and resolutions


Last night, we found a schema bug that returns error:400 when the input altitude is one-digit.
After a few tests, we focused on the regex expression given by the TA. We fixed this bug by updating the regex expression.



## Retrospective (focus on people, process, tools)

In this sprint, we encountered the communication problems again. Two team members did the duplicate work so that wasted the time for more jobs.
This Tuesday, we had an appointment with Dave to consult for advice of communication. Now we cam better use Slack to communicate with every group member instead of 1 on 1 before.

#### What we changed this sprint

We have a better optimization function to plan the route.

We update our database to make it work well worldwide.

Now we can also output CSV and KML besides txt formats. The KML format works well showing the itinerary on the Google Earth.

It now can give a banner when something goes wrong.
#### What we did well

We learnt how to communicate efficiently. Team members ask others process before starting a new task.

#### What we need to work on

We need to add more tests to increase the test coverage. Our team needs to refactor some of our codes like Itinerary.js because it's too long and complicated. We should split this kind of file into smaller classes.

#### What we will change next sprint 

We will change our code structure to improve the maintainability.
