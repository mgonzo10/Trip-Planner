# Sprint 5 - *T02* - *The Two Twos*

## Goal
Complete all assigned Epics efficiently and effectively using good teamwork and good coding practices.
### A Beautiful User Experience! 
### Sprint Leader: *Joel Topps*

## Definition of Done

* Version in pom.xml should be `<version>5.0.0</version>` for your final build for deployment.
* Increment release `v5.0` created on GitHub with appropriate version number and name.
* Increment `server-5.0.jar` deployed for testing and demonstration on SPRINT5 assignment.
* Sprint Review, Restrospective, and Metrics completed (team/sprint5.md).


## Policies

#### Mobile First Design!
* Design for mobile, tablet, laptop, desktop (in that order).
* Use ReactStrap for a consistent interface (no HTML, CSS, style, etc.).
* Must adhere to the TripCo Interchange Protocol (TIP) for interoperability and testing.
#### Clean Code
* Code Climate maintainability of A or B.
* Code adheres to Google style guides for Java and JavaScript.
#### Test Driven Development
* Write method headers, unit tests, and code in that order.
* Unit tests are fully automated.
* Code Coverage above 50%
#### Configuration Management
* Always check for new changes in master to resolve merge conflicts locally before committing them.
* All changes are built and tested before they are committed.
* All commits include a task/issue number.
* All commits include tests for the added or modified code.
* All tests pass.
#### Continuous Integration / Delivery 
* Master is never broken.  If broken, it is fixed immediately.
* Continuous integration successfully builds and tests all pull requests for master branch.
* All Java dependencies in pom.xml.  Do not load external libraries in your repo. 
* Each team member must complete Interop with another team and file an issue in the class repo with the results.
  * title is your team number and your name,
  * labels should include Interop and the Team that you tested with,
  * description should include a list of tests performed, noting any failures that occurred.

## Plan

This sprint will complete the following Epics.

* *#269 I want to know where I am on the map: use browsers geolocation to show location*
* *#266 It would be nice to see a map with the calculator: show map that displays origin, destination, and path between them*
* *#264 Let me choose from different map backgrounds: allow user to choose from different backgrounds for the map*
* *#262 Give me the shortest trips possible: 3-Opt*

# Client Component Heirarchy:
![Client](https://github.com/csucs314s19/t02/blob/master/team/Images/client-component-hierarchy.PNG)

# Server Heirarchy:
![Server](https://github.com/csucs314s19/t02/blob/master/team/Images/client-server-interact.PNG)

# UI:
![Diagrams](https://github.com/csucs314s19/t02/blob/master/team/Images/ui.PNG)

## Interops

| Name | Team Tested | Issues Found | Other Comments |
| :--- | :--- | :--- | :--- |
| Joel | T08 | They weren't able to load world237.json, markers don't clear after removing that location from itinerary, their server white screens our client, not able to choose what to display on tables | unsure if their server was the problem or if it was ours.... |
| Maritza | T19 | Our server is not loading on other people's clients, but team 19's server is compatibile and works well with out client, expect markers. | think our problem is the our server tho |
| Wenrui | T11 | When using our client, if we directly search before uploading a file, the page will crash. | Further look at MapMarker |
| Wenhao | T01 | Their client with our server crashes on when I click the Short button, and on ours client also don't work with theirs server. It seems like that the format don't match each others' data.  | Our format of Optimization maybe don't match theirs |

## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | *4* | *3* |
| Tasks |  *17*   | *14* | 
| Story Points |  *23*  | *19* | 


## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| *4/24* | *none* | *#263, #271* | *none* | 
| *4/29* | *none* | *273, 269, 270* | *none* |
| *5/1* | *273, 269, 270* | *263, 267, 228* |*team spread thin as finals approach*|
| *5/3* | *none* | *263, 267, 228* | *struggled getting time to work on things together* |
| *5/6* | *none* | *263, 267, 228* | *time* |
| *5/8* |*276, 232*| *263, 267, 228* | *time* |

## Review (focus on solution and technology)

In this sprint, we focused entirely on the User Interface. All of our completed epics and tasks had the goal of creating the best possible experience for the user. Due to this prioritization, we were unable to complete 3-Opt, but feel that the most important thing for us was fixing our "rough around the edges" UI. 

#### Completed epics in Sprint Backlog 

These Epics were completed.

* *#269 I want to know where I am on the map: This epic was very simple for us as we had already done something similar*
* *#266 It would be nice to see a map with the calculator: This was a last minute add for us and wasn't super complex.*
* *#264 Let me choose from different map backgrounds: This took a little time as our itinerary map had alot going on and we had to learn how to interconnect things, but once we got it things went quick.*

#### Incomplete epics in Sprint Backlog 

These Epics were not completed.

* *#262 Give me the shortest trips possible: We chose to make this our last priority after we finished any UI issues. We decided on this because we have had UI issues on demos in the past and wanted to ensure that didn't happen again.*


#### What went well

The team did a great job talking through and prioritizing what we needed to accomplish. We also had many bugs that we caught and fixed throughout the process which hadn't happened in previous sprints.This will hopefully pay off come demo day.


#### Problems encountered and resolutions

The team had some minor time issues which resulted in us putting off starting work on the sprint. These were caused by the semester coming to a close and all of us having multiple projects due throughout all of our classes. We resolved it by cutting 3-Opt and lightening our workload so we could deliver less features that were high quality as opposed to more features that maybe weren't 100% ready.


## Retrospective (focus on people, process, tools)

In this sprint, we worked more as a team by all working together on epics. However, we did start work a little late which is reflected in our burndown chart. We didn't have any serious issues this sprint besides just having team members being spread to thin between all their classes.

#### What we changed this sprint

Our changes for this sprint included us focusing on the User interface. We also all worked together to tackle epics efficiently instead of doing our usual divide and conquer strategy.

#### What we did well

We prioritized epics and worked together as a team to complete them. 

#### What we need to work on

We could improve on our use of Zenhub. There were multiple times where pull requests weren't attached to issues and sometimes issues/epics weren't completely filled out. We lost points in our sprint5 plan because of this since zenhub couldn't accurately count our story points.

#### What we will change next sprint 

We will change our employer. TripCo is closing down for the summer season.
