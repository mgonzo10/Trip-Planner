# Sprint 3 - *t02* - *two twos*

## Goal

### Shorter trips to more places!
### Sprint Leader: *Wenrui Ma*

## Definition of Done

* Version in pom.xml should be `<version>3.0.0</version>` for your final build for deployment.
* Increment release `v3.0` created on GitHub with appropriate version number and name.
* Increment `server-3.0.jar` deployed for testing and demonstration on SPRINT3 assignment.
* Sprint Review, Restrospective, and Metrics completed (team/sprint3.md).


## Policies

#### Mobile First Design!
* Design for mobile, tablet, laptop, desktop (in that order).
* Use ReactStrap for a consistent interface (no HTML, CSS, style, etc.).
* Must adhere to the TripCo Interchange Protocol (TIP) for interoperability and testing.
#### Clean Code
* Code Climate maintainability of A or B.
* Code adheres to Google style guides for Java and JavaScript.
#### Test Driven Development
* Write method headers, unit tests, and code in that order.
* Unit tests are fully automated.
* Code Coverage above 40%
#### Configuration Management
* Always check for new changes in master to resolve merge conflicts locally before committing them.
* All changes are built and tested before they are committed.
* All commits include a task/issue number.
* All commits include tests for the added or modified code.
* All tests pass.
#### Continuous Integration / Delivery 
* Master is never broken.  If broken, it is fixed immediately.
* Continuous integration successfully builds and tests all pull requests for master branch.
* All Java dependencies in pom.xml.  Do not load external libraries in your repo. 


## Plan

This sprint will complete the following Epics.

* *#133 User: Let me Change Itinerary: this is priority number 1.*
* *#129 User: Make my trip shorter: was added in a scrum planning session later in t*
* *#84  User: Show me a map and itinerary for my trip: we had almost completed this one last sprint and hoped to get it done quick*
* *#130 Data shouldn't go away when I change tabs: Should be more then manageable to complete.*

In our planning we strive for well written and tested epics and are willing to sacrifice completing fewer epics if it means that the ones we do complete are well written and tested.


## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | *6* | *4* |
| Tasks |  *45*   | *39* | 
| Story Points |  *43*  | *41* | 


## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| *3/4/2019* | *none, still in planning phase* | *89* | *just started, more tasks will be assigned soon* | 
| *3/25/2019*| *none, group didn't accomplish much over break.| *136, 138, 140, 168*| *we replanned alot in this scrum*|
| *3/27/2019* | *136,138,140* | *168,129, writing tests* | *none* | 
| *3/28/2019* | *179,178, 184, 177, 161* | *168* | *none* | 


## Review (focus on solution and technology)

In this sprint, we completed 3 important Epics and began on the remaining two that we have. The code is up to ~40% code coverage and the master is performing all merged requests as they are expected. We opted to ensure that fewer epics were completed effectively instead of half heartedly spreading ourselves to thin on more epics. Quality over Quantity is the approach we felt most appropriate for the product we hope to deliver.

#### Completed epics in Sprint Backlog 

These Epics were completed.

* *#129 User: Make my Trip Shorter: Was put off until the end but fortunately was relatively quick for Ma to knock out.*
* *#130 Data shouldn't go away when I change tabs: Li was able to effectively and efficiently save the data to states as directed.*
* *#133 User: Let me Change Itinerary: Our group prioritized this epic and diverted most of our manpower to completing this epic.*
* *#84 User: Show me a map and itinerary for my trip: This was an epic that we had mostly completed for awhile but left partially finished while we dragged our feet on the "be able to choose what to display for each destination in the itinerary". Once we finally got around to it, it was completed very quickly.*

#### Incomplete epics in Sprint Backlog 

These Epics were not completed.

* *#139 TripCo:Validate all requests sent to the server and responses received by the client: We put this epic in the icebox and prioritized other epics over this. By the time we reached it, we had ran out of time to finish it fo this sprint.*
* *#132 User: Give me a friendly message if something goes wrong: Was prioritized last by the team, and wasn't reached in time.*

#### What went well

We completed everything we set out to complete. We were able to resolve minor problems in the code and keep pressing forward.


#### Problems encountered and resolutions

The team had a few problems with cookies crashing pages and with Travis breaking on the final day of the sprint. These slowed the team down but ultimately we were able to figure out the pages crashing and Travis resolved itself.


## Retrospective (focus on people, process, tools)

In this sprint, we got alot of work done, but struggled with communication (recurring theme from previous sprints) and had duplicate work being done by multiple people. This resulted in time wasted that could've been directed at completing another epic. The Travis tool was also difficult as it would either pass a build and then go back and fail it later, or was completely out for the count.

#### What we changed this sprint

Our changes for this sprint included setting more realistic goals for the team and accepting that we won't finish every epic. This took a significant amount of stress off the teams shoulders.

#### What we did well

We got alot of work done and completed most of the epics that we set out to complete. For the most part (with the exception of spring break), we all stayed busy and actively worked on the project.

#### What we need to work on

Our team really needs to work on communication. We had a couple situations where when completing tasks multiple people were working on the same code, resulting in significant wasted time that could've been better utilized elsewhere. Had we communicated better we possibly could've completed another epic.

#### What we will change next sprint 

We will have to start communicating more effectively and planning a little more in depth. We need to be actively writing tests and have testing to commit on each pull request as opposed to writing tests later after all is done. 
