# Sprint 2 - *t02* - *The TwoTwos*

## Goal

### A map and itinerary!
### Complete a total of six well written and well tested Epics
##### really work on testing

### Sprint Leader: *Maritza Gonzalez*

## Definition of Done

* Version in pom.xml should be `<version>2.0.0</version>` for your final build for deployment.
* Increment release `v2.0` created on GitHub with appropriate version number and name.
* Increment deployed for testing and demonstration on SPRINT2 assignment.
* Sprint Review and Restrospectives completed (team/sprint2.md).
* Has appropriate testing function for each large epic


## Policies

#### Mobile First Design!
* Design for mobile, tablet, laptop, desktop (in that order).
* Use ReactStrap for a consistent interface (no HTML, CSS, style, etc.).
* Must adhere to the TripCo Interchange Protocol (TIP) for interoperability and testing.
#### Clean Code
* Code Climate maintainability of A or B.
* Code adheres to Google style guides for Java and JavaScript.
#### Test Driven Development
* Write method headers, unit tests, and code in that order.
* Unit tests are fully automated.
#### Configuration Management
* Always check for new changes in master to resolve merge conflicts locally before committing them.
* All changes are built and tested before they are committed.
* All commits include a task/issue number.
* All commits include tests for the added or modified code.
* All tests pass.
#### Continuous Integration / Delivery 
* Master is never broken.  If broken, it is fixed immediately.
* NO COMMITS TO MASTER.  If broken, an apology must be sent on slack and buy snacks for the rest of the team.
* Continuous integration successfully builds and tests all pull requests for master branch.
* All Java dependencies in pom.xml.  Do not load external libraries in your repo. 


## Plan

This sprint will complete the following Epics.

* *#0 epic title: description*
* *#77 User: Enter latitudes and longitudes in the calculator using degree-minute-second and other formats.*
* *#23 User: I want to know where I am on the map*
* *#80 User: The calculator data shouldn't go away when units change*
* *#87 User: Let me choose from different map backgrounds.*
* *#76 User: I may need distances in other units of measure*
* *#84 User: Show me a map and itinerary for my trip*

Key planning decisions for this sprint include ...

* Breaking up tasks more equally
* Smaller tasks
* An equal rotation of how tasks are handled


## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | *6* | *value* |
| Tasks |  *12*   | *value* | 
| Story Points |  *17*  | *value* | 


## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| *2/13* | *none* | *34, 82, 92, 91* | *none* |
| *2/15* | *34,* | *82, 85, 88, 92, 91* | *Understanding HTTP Codes* | 
| *2/18* | *82*| *83,92,88,95,78*| *none*|
| *2/20* | *80,83*|*85, 84, 92,88,95,78*|*Spread ourselves to thin/ didn't prioritize appropriately*|
| *2/22* | *101,103,104,105,106, 107, 108, 109, 85, 92* | *90, 77, 88, 95, 78* | *poor initial planning, need to remeet with group and straighten new plan out*|


## Review (focus on solution and technology)

In this sprint, we become more familiar with how the client and server communicates, also the reactjs. But it is pretty frustrating that sometimes a small bug takes hours to fix due to lack of knowlegde with reactjs.

#### Completed epics in Sprint Backlog 

These Epics were completed.

* *## epic title: comments*
* *23- "User: I want to know where I am on the map": Set Default to CSU Oval coordinates.*
Uses the browsers geolocation api.
* *87- "User: Let me choose from different map backgrounds.: very short. purely aesthetic.*"
Different types of overlays of leaflet.
* *80- "User": The calculator data shouldn't go away when units change*
Uses cookies.
* *77- "User": Enter latitudes and longitudes in the calculator using degree-minute-second and other formats.*
Using regular expressions. But further error handling needed.

#### Incomplete epics in Sprint Backlog 

These Epics were not completed.

* *## epic title: explanation*
* *76- "User": I may need distances in other units of measure*
Proved to be more difficult than originally anticipated. We prioritized the itinerary funcitions before this.
* *84- "User": Show me a map and itinerary for my trip*
Finished all tasks except "Enable the user to choose what to display for each destination in the itinerary".



#### What went well

The team cohesion.
Learning new stuff like Travis.


#### Problems encountered and resolutions

Figuring out how to use the leaflet library and draw the marker and the lines took us lots of time, but enventually we were able to display it. However,


## Retrospective (focus on people, process, tools)

In this sprint, we did not work together consistently. Procrastianted until Checks and Deploys. Learned how to use Travis efficiently, and addded test. However, we need to improve our skills to write tests escpecially for the client side to better enhance our code coverage and to do test-driven development.

#### What we changed this sprint

Our changes for this sprint included making tests, becoming more aware of how the client interacts with the server and utilizing interops to help further test our client and server.

#### What we did well

Problem solved together.
Seeked help proactively.
Made attainable goals.

#### What we need to work on

Time devoted did not reflect the final projects, we need to learn how to code better not longer.

#### What we will change next sprint 

Need to make smaller more defined tasks, divide and conquer. Code together more often.
